import { coreTaskIngressService } from '../services/coreTaskIngressService';
import { externalConnectionUiService, type ExternalConnectionConfig, type ExternalConnectionView } from '../services/externalConnectionUiService';
import { generalWorkspaceService, type WorkspaceMode, type WorkspaceRecord } from '../services/generalWorkspaceService';
import { reviewZipExportService, type ReviewPackageLedgerRecord, type ReviewZipArtifact } from '../services/reviewZipExportService';
import { externalReviewIntakeService, type ExternalReviewRecord, type ExternalReviewDecisionValue } from '../services/externalReviewIntakeService';
import { webResearchPolicyService, type WebResearchPolicy, type WebResearchPolicyReceipt } from '../../research/services/webResearchPolicyService';
import { researchQueryPlanningService, type QueryPlanningPolicy, type ResearchQueryPlan } from '../../research/services/researchQueryPlanningService';
import { coreCycleSettingsService, type CoreCycleSettings } from '../services/coreCycleSettingsService';
import { selfCodeSpaceService } from '../services/selfCodeSpaceService';

export type UiOperation =
  | 'LIST_EXTERNAL_CONNECTIONS' | 'SAVE_EXTERNAL_CONNECTION_CONFIG' | 'TEST_EXTERNAL_CONNECTION' | 'EXPORT_EXTERNAL_CONNECTION_CONFIG'
  | 'LIST_WORKSPACES' | 'CREATE_GENERAL_WORKSPACE' | 'SAVE_WORKSPACE_CANDIDATE' | 'ANALYZE_VBA_WORKSPACE' | 'EXPORT_VBA_CODE'
  | 'LIST_REVIEW_PACKAGES' | 'REGENERATE_REVIEW_PACKAGE' | 'DOWNLOAD_REVIEW_PACKAGE' | 'IMPORT_EXTERNAL_AI_REVIEW' | 'DECIDE_CANDIDATE_ADOPTION'
  | 'GET_WEB_RESEARCH_POLICY' | 'SAVE_WEB_RESEARCH_POLICY';
export interface UiCommand<T=Record<string,unknown>> { commandId:string; operation:UiOperation; payload:T; requestedAt:number; sourceScreenId:string; workspaceId?:string; expectedRevision?:string; }
export interface UiCommandResult<T=unknown> { commandId:string; taskId?:string; status:'SUCCESS'|'BLOCKED'|'FAILED'; summary:string; data?:T; receiptIds:string[]; diagnosticIds:string[]; nextActions:string[]; completedAt:number; }
let uiCommandSequence=0;
const id=()=>{uiCommandSequence+=1;return `UIC-${Date.now()}-${String(uiCommandSequence).padStart(8,'0')}`;};
class TypedCoreUiGatewayService {
 commandId(){return id();}
 getResearchQueryPlanningPolicy():QueryPlanningPolicy{return researchQueryPlanningService.getPolicy();}
 async saveResearchQueryPlanningPolicy(policy:QueryPlanningPolicy):Promise<UiCommandResult<{policy:QueryPlanningPolicy;receiptId:string;policySha256:string}>>{const commandId=id();try{const task=await coreTaskIngressService.submit({goal:'自律Query設計Policyを保存する',source:'core',initialPayload:{operation:'SAVE_RESEARCH_QUERY_POLICY',policy},kind:'SYSTEM_TASK'});if(task.task.status!=='COMPLETED')return {commandId,taskId:task.task.taskId,status:'BLOCKED',summary:'coreがQuery Policy保存を完了していません',receiptIds:[],diagnosticIds:['CORE_COMPLETION_REQUIRED'],nextActions:['REVIEW_CORE_TASK'],completedAt:Date.now()};const saved=researchQueryPlanningService.savePolicy(policy);return {commandId,taskId:task.task.taskId,status:'SUCCESS',summary:'自律Query設計設定を保存しました',data:saved,receiptIds:[saved.receiptId],diagnosticIds:[],nextActions:[],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 async buildResearchQueryPlan(question:string):Promise<UiCommandResult<{plan:ResearchQueryPlan}>>{const commandId=id();try{const task=await coreTaskIngressService.submit({goal:'18分類でResearch Query Planを構築する',source:'core',initialPayload:{operation:'BUILD_RESEARCH_QUERY_PLAN',canonicalResearchIntent:question},kind:'SYSTEM_TASK'});if(task.task.status!=='COMPLETED')return {commandId,taskId:task.task.taskId,status:'BLOCKED',summary:'coreがQuery Plan構築を完了していません',receiptIds:[],diagnosticIds:['CORE_COMPLETION_REQUIRED'],nextActions:['REVIEW_CORE_TASK'],completedAt:Date.now()};const plan=researchQueryPlanningService.buildPlan(question);return {commandId,taskId:task.task.taskId,status:'SUCCESS',summary:'Research Query Planを作成しました',data:{plan},receiptIds:[`RQP-RECEIPT-${plan.planSha256.slice(0,20)}`],diagnosticIds:[],nextActions:['REVIEW_QUERY_PLAN'],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 getWebResearchPolicy():WebResearchPolicy{return webResearchPolicyService.get();}
 async saveWebResearchPolicy(policy:WebResearchPolicy):Promise<UiCommandResult<{policy:WebResearchPolicy;receipt:WebResearchPolicyReceipt}>>{const commandId=id();try{const task=await coreTaskIngressService.submit({goal:'Web調査Policyを保存する',source:'core',initialPayload:{operation:'SAVE_WEB_RESEARCH_POLICY',policy},kind:'SYSTEM_TASK'});if(task.task.status!=='COMPLETED')return {commandId,taskId:task.task.taskId,status:'BLOCKED',summary:'coreが設定保存を完了していません',receiptIds:[],diagnosticIds:['CORE_COMPLETION_REQUIRED'],nextActions:['REVIEW_CORE_TASK'],completedAt:Date.now()};const receipt=webResearchPolicyService.save(policy);return {commandId,taskId:task.task.taskId,status:'SUCCESS',summary:'Web確認件数設定を保存しました',data:{policy:webResearchPolicyService.get(),receipt},receiptIds:[receipt.receiptId],diagnosticIds:[],nextActions:[],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 listExternalConnections():ExternalConnectionView[]{return externalConnectionUiService.list();}
 async saveExternalConnection(config:ExternalConnectionConfig,secret?:string):Promise<UiCommandResult<ExternalConnectionView[]>>{const commandId=id();try{const x=await externalConnectionUiService.save(config,secret);return {commandId,taskId:x.coreTaskId,status:'SUCCESS',summary:'設定をcore経由で保存しました',data:this.listExternalConnections(),receiptIds:[x.configReceiptId,...(x.secretReceiptId?[x.secretReceiptId]:[])],diagnosticIds:[],nextActions:['TEST_EXTERNAL_CONNECTION'],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 async testExternalConnection(connectionId:string):Promise<UiCommandResult<ExternalConnectionView[]>>{const commandId=id();try{const x=await externalConnectionUiService.test(connectionId as ExternalConnectionConfig['id']);return {commandId,taskId:x.coreTaskId,status:x.status==='AVAILABLE'?'SUCCESS':'BLOCKED',summary:x.sanitizedMessage||x.status,data:this.listExternalConnections(),receiptIds:[],diagnosticIds:x.failureStage?[`${x.config.id}:${x.failureStage}`]:[],nextActions:x.status==='AVAILABLE'?[]:['OPEN_CONNECTION_SETTINGS'],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 exportExternalConnections():Blob{return new Blob([externalConnectionUiService.exportSanitized()],{type:'application/json;charset=utf-8'});}
 listWorkspaces():WorkspaceRecord[]{return generalWorkspaceService.list();}
 getSelfCodeSnapshot(){return selfCodeSpaceService.get();}
 async overwriteSelfCodeWithBundledSeed(
  onProgress?: Parameters<
    typeof selfCodeSpaceService.initializeBundledSeed
  >[1]
){
  return selfCodeSpaceService.initializeBundledSeed(
    true,
    onProgress
  );
}
 getSelfCodeGitHubSettings(){return selfCodeSpaceService.getGitHubSettings();}
 getSelfCodeGitHubPat(){return selfCodeSpaceService.getGitHubPat();}
 saveSelfCodeGitHubPat(token:string){return selfCodeSpaceService.saveGitHubPat(token);}
 saveSelfCodeGitHubSettings(input:{repository:string;branch:string;commitMessage:string}){return selfCodeSpaceService.saveGitHubSettings(input);}
 listSelfCodeFiles(){return selfCodeSpaceService.listFiles();}
 readSelfCodeFile(path:string){return selfCodeSpaceService.readFile(path);}
 searchSelfCode(query:string){return selfCodeSpaceService.search(query);}
 async syncSelfCode(
  token?:string,
  onProgress?:Parameters<typeof selfCodeSpaceService.sync>[1]
 ){return selfCodeSpaceService.sync(token,onProgress);}
 async pushSelfCode(commitMessage='Update self code space'):Promise<UiCommandResult<any>>{const commandId=id();try{const token=selfCodeSpaceService.getGitHubPat();const snapshot=await selfCodeSpaceService.push(token,commitMessage);return {commandId,taskId:'SELF_CODE_PUSH',status:'SUCCESS',summary:'自己コードをGitHubへPUSHしました',data:snapshot,receiptIds:[],diagnosticIds:[],nextActions:[],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 async createWorkspace(input:{name:string;workspaceMode:WorkspaceMode;assetKind:string;sourceLocator:string;baseContent:string;trustStatus?:WorkspaceRecord['trustStatus'];targetEnvironment?:string}):Promise<UiCommandResult<WorkspaceRecord>>{const commandId=id();try{const row=await generalWorkspaceService.create(input);return {commandId,taskId:row.coreTaskId,status:'SUCCESS',summary:'Workspaceをcore経由で作成しました',data:row,receiptIds:[row.baseSnapshotId],diagnosticIds:[],nextActions:['SAVE_WORKSPACE_CANDIDATE'],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 async saveWorkspaceCandidate(workspaceId:string,content:string):Promise<UiCommandResult<WorkspaceRecord>>{const commandId=id();try{const row=await generalWorkspaceService.setCandidate(workspaceId,content);return {commandId,taskId:row.coreTaskId,status:'SUCCESS',summary:'Candidate Revisionを保存しました',data:row,receiptIds:row.candidateRevisionId?[row.candidateRevisionId]:[],diagnosticIds:[],nextActions:['ANALYZE_VBA_WORKSPACE'],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 analyzeVba(workspaceId:string){return generalWorkspaceService.analyzeVba(workspaceId);}
 exportVbaCode(workspaceId:string):Blob{return generalWorkspaceService.exportVbaCode(workspaceId);}
 getCoreCycleSettings():CoreCycleSettings{return coreCycleSettingsService.get();}
 async saveCoreCycleSettings(settings:CoreCycleSettings):Promise<UiCommandResult<{settings:CoreCycleSettings}>>{const commandId=id();try{const task=await coreTaskIngressService.submit({kind:'SYSTEM_TASK',goal:'COREサイクル上限設定を保存する',source:'core',payload:{operation:'SAVE_CORE_CYCLE_SETTINGS',settings}});if(task.task.status!=='COMPLETED')return {commandId,taskId:task.task.taskId,status:'BLOCKED',summary:'coreがサイクル設定保存を完了していません',receiptIds:[],diagnosticIds:['CORE_COMPLETION_REQUIRED'],nextActions:['REVIEW_CORE_TASK'],completedAt:Date.now()};const saved=coreCycleSettingsService.save(settings);return {commandId,taskId:task.task.taskId,status:'SUCCESS',summary:'COREサイクル設定を保存しました',data:{settings:saved},receiptIds:[`CORE-CYCLE-${Date.now()}`],diagnosticIds:[],nextActions:[],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 async submitConversation(text:string,hasAttachments=false){return coreTaskIngressService.submit({kind:'USER_REQUEST',goal:text,source:'conversation',payload:{text,hasAttachments,entry:'TYPED_CONVERSATION_UI_GATEWAY'}});}
 finalizeConversationResponse(taskId:string,response:unknown){return coreTaskIngressService.finalizeConversationResponse(taskId,response);}
 listReviewPackages():ReviewPackageLedgerRecord[]{return reviewZipExportService.list();}
 async regenerateReviewPackage(packageId:string){return reviewZipExportService.regenerate(packageId);}
 downloadReviewPackage(artifact:ReviewZipArtifact){return reviewZipExportService.download(artifact);}
 getExternalReviewDraft(packageId:string):string{return externalReviewIntakeService.getDraft(packageId);}
 saveExternalReviewDraft(packageId:string,rawResponse:string):void{externalReviewIntakeService.saveDraft(packageId,rawResponse);}
 listExternalReviews(packageId?:string):ExternalReviewRecord[]{return externalReviewIntakeService.list(packageId);}
 async importExternalReview(input:Parameters<typeof externalReviewIntakeService.importResponse>[0]){return externalReviewIntakeService.importResponse(input);}
 async submitExternalReviewDecision(input:Parameters<typeof externalReviewIntakeService.submitDecision>[0]){return externalReviewIntakeService.submitDecision(input);}
 async submit(operation:string,payload:Record<string,unknown>,sourceScreenId:string):Promise<UiCommandResult>{const commandId=id();try{const result=await coreTaskIngressService.submit({kind:'USER_REQUEST',goal:`UI ${sourceScreenId} requested ${operation}`,source:'conversation',payload:{operation,...payload,uiCommandId:commandId,sourceScreenId}});const completed=result.task.status==='COMPLETED';return {commandId,taskId:result.task.taskId,status:completed?'SUCCESS':'BLOCKED',summary:completed?'core処理が完了しました':`core処理は${result.task.status}です`,receiptIds:[],diagnosticIds:[],nextActions:completed?[]:['OPEN_TASK_DIAGNOSTICS'],completedAt:Date.now()};}catch(e){return this.failed(commandId,e);}}
 private failed<T>(commandId:string,error:unknown):UiCommandResult<T>{return {commandId,status:'FAILED',summary:error instanceof Error?error.message:String(error),receiptIds:[],diagnosticIds:[],nextActions:['RETRY'],completedAt:Date.now()};}
}
export const typedCoreUiGatewayService=new TypedCoreUiGatewayService();
export type { CoreCycleSettings, ExternalConnectionConfig, ExternalConnectionView, WorkspaceMode, WorkspaceRecord, ReviewPackageLedgerRecord, ExternalReviewRecord, ExternalReviewDecisionValue, QueryPlanningPolicy, ResearchQueryPlan };
