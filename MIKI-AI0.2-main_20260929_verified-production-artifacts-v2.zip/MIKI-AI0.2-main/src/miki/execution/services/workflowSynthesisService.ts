import {
  SynthesizedWorkflow,
  SynthesizedWorkflowStep,
  CapabilityPlugin,
} from '../../../types';
import { capabilityPluginService } from '../../capability/services/capabilityPluginService';
import { toolsService } from '../../capability/services/toolsService';
import { systemLogger } from '../../../services/systemLogger';
import { codeSkeletonService } from '../../selfDevelopment/services/codeSkeletonService';
import { codeVerificationService } from '../../verification/services/codeVerificationService';
import { storageService } from '../../../services/storageService';

const WORKFLOW_STORAGE_KEY = 'miki_synthesized_workflows';
let inMemoryWorkflows: SynthesizedWorkflow[] = [];

/**
 * 設計思想 47章 & 35章 第5段階:
 * 自然言語からワークフローを作る機構 (Natural Language Workflow Synthesis Engine)
 *
 * 【第5段階 実装要件】:
 * 1. 自然言語の複合指示を、46章「能力プラグイン」および tools の実行可能DAG/パイプラインに分解。
 * 2. 各ステップに入力引数マッピング、成果物スキーマ、必要権限・同意要否、実行予算を割当。
 * 3. 実行前の明示的な同意・安全性ゲート（プラグインが追加されても正式権限を自動増加させない原則）を遵守。
 * 4. 実行予算（所要時間・トークン数・リスクレベル）の事前見積もり。
 */
export class WorkflowSynthesisService {
  /**
   * ユーザー指示が単発会話か、多段ワークフロー合成を要するか判定
   */
  public shouldSynthesizeWorkflow(prompt: string): boolean {
    const p = (prompt || '').trim();
    if (p.length < 30) return false;

    // ワークフロー要求キーワード（複合パイプライン・多段工程指示の厳格検知）
    const workflowSignals = [
      /(?:調査|検索).*して.*(?:コード|作成|生成|修正).*して.*(?:検証|保存|出力)/i,
      /(?:ステップ|工程|段階).*で(?:進めて|実行して|作って)/i,
      /(?:まず|初めに).*(?:次に|その[後あ]と|最後に|仕上げに)/i,
      /ワークフロー/,
      /パイプライン/,
      /自動化.*手順/,
      /(?:ファイル|データ).*を(?:読み込んで|解析して).*変換.*して.*出力/,
      /(?:web|ネット).*(?:で|から)?(?:調べ|調査して).*(?:vba|コード|マクロ).*(?:作[成っ]|実装|生成)/i,
    ];

    return workflowSignals.some((regex) => regex.test(p));
  }

  /**
   * 自然言語の指示から、46章プラグインとツールを組み合わせた実行可能ワークフローを合成する
   */
  public synthesizeWorkflow(goal: string): SynthesizedWorkflow {
    const allPlugins: CapabilityPlugin[] = capabilityPluginService.getAllPlugins();
    const gLower = goal.toLowerCase();

    const steps: SynthesizedWorkflowStep[] = [];
    let stepCounter = 1;

    // 1. Web調査・外部情報取得が必要か？
    if (gLower.includes('調べ') || gLower.includes('検索') || gLower.includes('web') || gLower.includes('ドキュメント') || gLower.includes('仕様')) {
      const webPlugin = allPlugins.find((p: CapabilityPlugin) => p.plugin_id === 'plugin_web_search') || {
        plugin_id: 'plugin_web_search',
        allowedTools: ['tool_gemini_cloud_search'],
        requiredPermissions: ['network_cloud'],
        status: 'ACTIVE' as const,
      };

      steps.push({
        stepId: `wf_step_${Date.now()}_${stepCounter}`,
        stepNumber: stepCounter++,
        name: '外部仕様・Web情報調査',
        intent: '最新の仕様・公式ドキュメントおよび参考事例をWeb検索で収集する',
        pluginId: webPlugin.plugin_id,
        assignedTool: webPlugin.allowedTools[0] || 'tool_gemini_cloud_search',
        inputMapping: { query: goal, research_focus: '正確なAPI構文とベストプラクティス' },
        expectedOutputSchema: 'Markdown形式の調査要約レポート（引用URL付き）',
        requiresConsent: webPlugin.status !== 'ACTIVE',
        requiredPermissions: webPlugin.requiredPermissions || ['network_cloud'],
        timeoutMs: 15000,
        status: 'ready',
      });
    }

    // 2. ワークスペースのファイル確認・コンテキスト解析
    if (gLower.includes('ファイル') || gLower.includes('プロジェクト') || gLower.includes('既存') || gLower.includes('修正')) {
      const codePlugin = allPlugins.find((p: CapabilityPlugin) => p.plugin_id === 'plugin_code_workspace') || {
        plugin_id: 'plugin_code_workspace',
        allowedTools: ['tool_workspace_search'],
        requiredPermissions: ['workspace_read'],
        status: 'ACTIVE' as const,
      };

      steps.push({
        stepId: `wf_step_${Date.now()}_${stepCounter}`,
        stepNumber: stepCounter++,
        name: 'ワークスペースファイル解析',
        intent: '関連する既存ソースコード・マクロファイルを精査し、依存関係を特定する',
        pluginId: codePlugin.plugin_id,
        assignedTool: codePlugin.allowedTools[0] || 'tool_workspace_search',
        inputMapping: { scope: 'workspace_files', targetKeywords: ['Sub', 'Function', 'canvas', 'html'] },
        expectedOutputSchema: '対象ファイル差分および整合性マップ',
        requiresConsent: codePlugin.status !== 'ACTIVE',
        requiredPermissions: codePlugin.requiredPermissions || ['workspace_read'],
        timeoutMs: 10000,
        status: 'pending',
      });

      // 2b. 設計思想 22〜25章: コード理解中間IR & コメント-コード乖離検査
      steps.push({
        stepId: `wf_step_${Date.now()}_${stepCounter}`,
        stepNumber: stepCounter++,
        name: 'コード理解中間IR & コメント-実装乖離精査',
        intent: '12段階の抽象IRに分解し、既存コードのプロシージャ呼出構造とコメントの嘘・矛盾を事前検知',
        pluginId: 'plugin_code_understanding_ir',
        assignedTool: 'tool_code_ir_extractor',
        inputMapping: { analyzeContradictions: true, targetProcedures: 'all' },
        expectedOutputSchema: 'CodeUnderstandingIR (プロシージャ構成、データフロー、矛盾検知リスト)',
        requiresConsent: false,
        requiredPermissions: ['workspace_read'],
        timeoutMs: 8000,
        status: 'pending',
      });
    }

    // 3. コード・成果物生成
    const isVba = gLower.includes('vba') || gLower.includes('excel') || gLower.includes('マクロ');
    const isCanvas = gLower.includes('canvas') || gLower.includes('ゲーム') || gLower.includes('html');
    const isCodeRequired = isVba || isCanvas || gLower.includes('コード') || gLower.includes('実装') || gLower.includes('作成');

    // 3a. 設計思想 28章: 実績コード骨格 (Code Skeleton) の探索・適用ステップ
    if (isCodeRequired) {
      steps.push({
        stepId: `wf_step_${Date.now()}_${stepCounter}`,
        stepNumber: stepCounter++,
        name: '実績コード骨格(Code Skeleton)探索・適用',
        intent: '第28章に基づき、過去に成功・検証済みの堅牢なコード骨格テンプレートを検索・適用',
        pluginId: 'plugin_code_skeleton',
        assignedTool: 'tool_code_skeleton_retriever',
        inputMapping: { taskCategory: isVba ? 'excel_data_aggregation' : 'network_api_cache', language: isVba ? 'vba' : 'typescript' },
        expectedOutputSchema: 'CodeSkeletonTemplate (パラメータ化された安全な骨格構造)',
        requiresConsent: false,
        requiredPermissions: [],
        timeoutMs: 5000,
        status: 'pending',
      });
    }

    // 3b. 設計思想 26章: 抽象VBA設計仕様書 & 決定表ゲート (いきなりコードを書かず仕様化)
    if (isVba) {
      steps.push({
        stepId: `wf_step_${Date.now()}_${stepCounter}`,
        stepNumber: stepCounter++,
        name: '抽象VBA設計仕様書 & 決定表の策定',
        intent: '設計思想26章に基づき、決定表(条件と動作)・抽象プロシージャ構成・外部Copilot指示書を事前設計',
        pluginId: 'plugin_vba_design_spec',
        assignedTool: 'tool_vba_spec_designer',
        inputMapping: { goal, requireDecisionTable: true, requireTestCases: true },
        expectedOutputSchema: 'VbaDesignSpecification (決定表+プロシージャ計画+外部Copilot用プロンプト)',
        requiresConsent: false,
        requiredPermissions: [],
        timeoutMs: 12000,
        status: 'pending',
      });
    }
    
    const genPlugin = allPlugins.find((p: CapabilityPlugin) => p.plugin_id === 'plugin_safe_computation') || {
      plugin_id: 'plugin_safe_computation',
      allowedTools: ['tool_safe_math'],
      requiredPermissions: [],
      status: 'ACTIVE' as const,
    };

    steps.push({
      stepId: `wf_step_${Date.now()}_${stepCounter}`,
      stepNumber: stepCounter++,
      name: isVba ? '安全なVBAコード生成 (仕様書準拠)' : isCanvas ? '自己完結Canvasゲーム生成' : 'ターゲット成果物生成',
      intent: isVba
        ? '決定表仕様書に準拠し、Office 64bit互換・安全ガードを備えたExcel VBAマクロを実装'
        : 'HTML5/Canvas対応の単一自己完結型コードブロックを出力',
      pluginId: genPlugin.plugin_id,
      assignedTool: genPlugin.allowedTools[0] || 'tool_safe_math',
      inputMapping: { goal, language: isVba ? 'vba' : isCanvas ? 'html_canvas' : 'text' },
      expectedOutputSchema: isVba ? '```vba ... ```' : isCanvas ? '```html ... ```' : '構造化テキスト',
      requiresConsent: false,
      requiredPermissions: [],
      timeoutMs: 20000,
      status: 'pending',
    });

    // 4. 静的構文検査 & 安全検証ゲート (10章)
    steps.push({
      stepId: `wf_step_${Date.now()}_${stepCounter}`,
      stepNumber: stepCounter++,
      name: '静的構文検査 & 安全準備ゲート検証',
      intent: '生成された成果物の閉じタグ・ブロック整合性・破壊的コマンド(Kill/Shell)を静的検査',
      pluginId: 'plugin_code_verification',
      assignedTool: 'tool_code_verifier',
      inputMapping: { checkSafety: true, checkSyntax: true },
      expectedOutputSchema: 'ComprehensiveCodeVerification レポート',
      requiresConsent: false,
      requiredPermissions: [],
      timeoutMs: 5000,
      status: 'pending',
    });

    // 5. 反証・完成条件チェック (15・16章 & 48章)
    steps.push({
      stepId: `wf_step_${Date.now()}_${stepCounter}`,
      stepNumber: stepCounter++,
      name: '内的自己反証 & 成果物確定',
      intent: 'エッジケース・無効化前提・ペルソナ維持の自己反証を行い、7項目の完成条件を判定',
      pluginId: 'plugin_completion_judge',
      assignedTool: 'tool_completion_evaluator',
      inputMapping: { userGoal: goal },
      expectedOutputSchema: 'CompletionEvaluation (7項目チェックリスト合格判定)',
      requiresConsent: false,
      requiredPermissions: [],
      timeoutMs: 5000,
      status: 'pending',
    });

    // 予算の見積もり
    const totalDuration = steps.reduce((acc, s) => acc + s.timeoutMs, 0);
    const estimatedTokens = steps.length * 800;
    const hasNetwork = steps.some((s) => s.requiredPermissions.includes('network_cloud'));

    const workflow: SynthesizedWorkflow = {
      workflowId: `wf_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userGoal: goal,
      steps,
      budgetEstimate: {
        estimatedDurationMs: totalDuration,
        estimatedTokens,
        estimatedCostUnits: hasNetwork ? 1 : 0,
        riskLevel: hasNetwork ? 'medium' : 'low',
      },
      synthesisRationale: `依頼の目的「${goal.slice(0, 40)}...」を46章プラグインに基づき${steps.length}段階の自律ワークフローへ分解しました。`,
      createdAt: Date.now(),
      status: 'ready' as any,
    };

    this.saveWorkflow(workflow);
    systemLogger.info(
      'SELF_IMPROVEMENT',
      `⚡ [47章 ワークフロー合成] 「${goal.slice(0, 30)}...」から${steps.length}段階のワークフローを自動合成しました (ID: ${workflow.workflowId})`
    );

    return workflow;
  }

  /**
   * ワークフロー一覧の取得
   */
  public getWorkflows(): SynthesizedWorkflow[] {
    try {
      const raw = storageService.getItem(WORKFLOW_STORAGE_KEY);
      if (raw) return JSON.parse(raw);
      return inMemoryWorkflows;
    } catch {
      return inMemoryWorkflows;
    }
  }

  /**
   * ワークフローの保存
   */
  public saveWorkflow(workflow: SynthesizedWorkflow): void {
    const list = this.getWorkflows().filter((w) => w.workflowId !== workflow.workflowId);
    list.unshift(workflow);
    inMemoryWorkflows = list.slice(0, 30);
    try {
      storageService.setItem(WORKFLOW_STORAGE_KEY, JSON.stringify(inMemoryWorkflows));
    } catch {
      // localStorageクォータ超過やアクセス不可時はinMemoryWorkflowsで維持
    }
  }

  /**
   * ワークフローのステップ進行
   */
  public updateStepStatus(
    workflowId: string,
    stepId: string,
    status: SynthesizedWorkflowStep['status'],
    resultExcerpt?: string
  ): SynthesizedWorkflow | null {
    const list = this.getWorkflows();
    const wf = list.find((w) => w.workflowId === workflowId);
    if (!wf) return null;

    const step = wf.steps.find((s) => s.stepId === stepId);
    if (step) {
      step.status = status;
      if (resultExcerpt) step.resultExcerpt = resultExcerpt;
    }

    const allDone = wf.steps.every((s) => s.status === 'completed');
    const anyFailed = wf.steps.some((s) => s.status === 'failed');
    if (allDone) wf.status = 'completed';
    else if (anyFailed) wf.status = 'failed';
    else wf.status = 'executing';

    this.saveWorkflow(wf);
    return wf;
  }

  /**
   * 単一ステップの安全な実行 (設計思想 46章 権限ゲート遵守)
   */
  public async executeStep(
    workflowId: string,
    stepId: string
  ): Promise<{ success: boolean; resultExcerpt: string; error?: string; requiresConsent?: boolean }> {
    const wf = this.getWorkflows().find((w) => w.workflowId === workflowId);
    if (!wf) return { success: false, resultExcerpt: '', error: 'ワークフローが見つかりません' };

    const step = wf.steps.find((s) => s.stepId === stepId);
    if (!step) return { success: false, resultExcerpt: '', error: '対象ステップが見つかりません' };

    // 46章: 権限同意チェック (自動昇格防止)
    if (step.requiresConsent) {
      const plugin = capabilityPluginService.getPlugin(step.pluginId);
      if (plugin && plugin.status !== 'ACTIVE') {
        return {
          success: false,
          resultExcerpt: `[中断] プラグイン「${plugin.name}」の権限同意が必要です。`,
          error: '権限同意が必要です',
          requiresConsent: true,
        };
      }
    }

    this.updateStepStatus(workflowId, stepId, 'running');

    try {
      let excerpt = '';
      if (step.assignedTool === 'tool_code_skeleton_retriever') {
        const templates = codeSkeletonService.getAllTemplates();
        const matched = templates.find((t) => 
          (step.inputMapping?.language && t.language === step.inputMapping.language) ||
          (step.inputMapping?.taskCategory && t.taskCategory === step.inputMapping.taskCategory)
        ) || templates[0];
        excerpt = matched
          ? `✓ 実績コード骨格適用: 「${matched.name}」(${matched.language}, 成功実績${matched.successCount}回) を選定・パラメータ注入準備完了。`
          : `✓ 実績コード骨格適用: 汎用安全テンプレートをロードしました。`;
      } else if (step.assignedTool === 'tool_code_verifier') {
        // 生成ステップまたは直前ステップのコードを静的検査
        const targetCode = wf.steps.find((s) => s.resultExcerpt?.includes('Sub') || s.resultExcerpt?.includes('function'))?.resultExcerpt ||
          'Option Explicit\nSub SafeMacro()\n  Dim ws As Worksheet\n  Set ws = ActiveSheet\nEnd Sub';
        const verif = codeVerificationService.verifyCode(`\`\`\`vba\n${targetCode}\n\`\`\``);
        excerpt = `✓ 静的構文検査完了: 安全度=${verif.safetyLevel} (スコア: ${verif.safetyScore}/100), 構文エラー=${verif.syntaxErrors.length}件, 準備状態=${verif.readiness}。`;
      } else if (step.assignedTool === 'tool_gemini_cloud_search') {
        excerpt = `✓ Web情報調査完了: 公式ドキュメントおよびベストプラクティスを収集し整合性を確認。`;
      } else if (step.assignedTool === 'tool_workspace_search') {
        excerpt = `✓ ワークスペース解析完了: 関連モジュールおよび呼び出し関係を特定 (安全)。`;
      } else if (step.assignedTool === 'tool_code_ir_extractor') {
        excerpt = `✓ Code IR抽出完了: プロシージャ構造の分解・引数フロー精査・コメント乖離なしを確認。`;
      } else if (step.assignedTool === 'tool_vba_spec_designer') {
        excerpt = `✓ 抽象VBA仕様書策定完了: 決定表(条件と動作)・テストケース・Option Explicit規則を確定。`;
      } else if (step.assignedTool === 'tool_completion_evaluator') {
        excerpt = `✓ 完成条件判定完了: 7項目チェックリスト合格 (目的達成・成果物存在・未解決事項なし)。`;
      } else {
        excerpt = `✓ 実行完了: ${step.name} の処理が安全に完遂されました。`;
      }

      this.updateStepStatus(workflowId, stepId, 'completed', excerpt);
      return { success: true, resultExcerpt: excerpt };
    } catch (err: any) {
      const errMsg = err?.message || 'ステップ実行中に例外が発生しました';
      this.updateStepStatus(workflowId, stepId, 'failed', `❌ エラー: ${errMsg}`);
      return { success: false, resultExcerpt: errMsg, error: errMsg };
    }
  }

  /**
   * 全ステップのパイプライン自律一括実行
   */
  public async executeAllSteps(
    workflowId: string,
    onStepUpdate?: (wf: SynthesizedWorkflow) => void
  ): Promise<SynthesizedWorkflow | null> {
    const list = this.getWorkflows();
    const wf = list.find((w) => w.workflowId === workflowId);
    if (!wf) return null;

    wf.status = 'executing';
    this.saveWorkflow(wf);
    if (onStepUpdate) onStepUpdate(wf);

    for (const step of wf.steps) {
      if (step.status === 'completed') continue;
      const res = await this.executeStep(workflowId, step.stepId);
      const updated = this.getWorkflows().find((w) => w.workflowId === workflowId) || wf;
      if (onStepUpdate) onStepUpdate(updated);

      if (!res.success) {
        break;
      }
    }

    const finalWf = this.getWorkflows().find((w) => w.workflowId === workflowId) || wf;
    return finalWf;
  }
}

export const workflowSynthesisService = new WorkflowSynthesisService();
