import {
  WorkManagerConstraints,
  WorkManagerStatus,
  BackgroundTaskExecutionLog,
  MemoryItem,
  ChatMessage,
  PersonaConfig,
  RegressionSuiteRunReport,
  BackgroundExecutionConditions,
} from '../../../types';
import { worldModelService } from '../../selfAwareness/services/worldModelService';
import { selfImprovementService } from '../../improvement/services/selfImprovementService';
import { selfImprovementIngressService } from '../../core/services/selfImprovementIngressService';
import { systemLogger } from '../../../services/systemLogger';
import { calculateDomainVector, calculateCosineSimilarity } from '../../../utils/memoryRetrieval';
import { nativeBackgroundService } from './nativeBackgroundService';
import { nativeWorkManagerService } from './nativeWorkManagerService';
import { storageService } from '../../../services/storageService';
import { skillsService } from '../../capability/services/skillsService';
import { regressionBenchmarkService } from '../../verification/services/regressionBenchmarkService';
import { deterministicRuntimeService } from '../../safety/services/deterministicRuntimeService';
import { syntheticDataService } from '../../research/services/syntheticDataService';
import { longTermMemoryService } from '../../memory/services/longTermMemoryService';
import { experienceLinkService } from '../../experience/services/experienceLinkService';
import { capabilityGapService } from '../../capability/services/capabilityGapService';
import { virtualTrainingService } from '../../learning/services/virtualTrainingService';
import { capabilityPluginService } from '../../capability/services/capabilityPluginService';
import { featureFlagsService } from '../../safety/services/featureFlagsService';
import { teacherRequestService } from '../../learning/services/teacherRequestService';
import { workingAgendaService } from '../../strategy/services/workingAgendaService';
import { unifiedWebResearchService } from '../../research/services/unifiedWebResearchService';
import { autonomousEvolutionService } from '../../autonomy/services/autonomousEvolutionService';
import { memoryAuditService } from '../../memory/services/memoryAuditService';
import { embeddingService } from '../../research/services/embeddingService';
import { storagePlanningService } from './storagePlanningService';
import { autonomousGrowthGovernorService } from '../../autonomy/services/autonomousGrowthGovernorService';
import { autonomousRevalidationLoopService } from '../../autonomy/services/autonomousRevalidationLoopService';
import { remediationExecutionCoordinatorService } from './remediationExecutionCoordinatorService';
import { remediationFailureRecoveryService } from '../../safety/services/remediationFailureRecoveryService';
import { virtualExperienceGeneratorService } from '../../experience/services/virtualExperienceGeneratorService';
import { faultInjectionLabService } from '../../verification/services/faultInjectionLabService';
import { specContractCompilerService } from '../../selfDevelopment/services/specContractCompilerService';
import { knowledgeHalfLifeService } from '../../memory/services/knowledgeHalfLifeService';
import { frontierGovernanceService } from '../../strategy/services/frontierGovernanceService';
import { autonomousHardeningService } from '../../autonomy/services/autonomousHardeningService';
import { answerPlanService } from '../../strategy/services/answerPlanService';
import { surfaceVariationGrowthService } from '../../conversation/services/surfaceVariationGrowthService';
import { bannedTopicsConfigService } from '../../safety/services/bannedTopicsConfigService';
import { WebMaterialPatternExtractor } from '../../research/services/webMaterialPatternExtractor';
import { conversationStrategyService } from '../../strategy/services/conversationStrategyService';

const WORK_MANAGER_CONSTRAINTS_KEY = 'miki_ai_workmanager_constraints';
const WORK_MANAGER_LOGS_KEY = 'miki_ai_workmanager_logs';
const WORK_MANAGER_CONFIG_KEY = 'miki_ai_workmanager_config';

/**
 * 浅い睡眠 (Shallow Sleep) 判定関数
 * 浅い睡眠: 索引更新・重複検出・ログ圧縮・メモリ整理など軽量処理
 */
export function canRunShallowSleep(c: BackgroundExecutionConditions): boolean {
  return !c.isUserActive && c.thermalState !== 'critical';
}

/**
 * 深い睡眠 (Deep Sleep) 判定関数
 * 深い睡眠: シャドー評価・A/Bテスト・教材生成・回帰ベンチマークなど重い処理
 */
export function canRunDeepSleep(c: BackgroundExecutionConditions): boolean {
  const normLevel = c.batteryLevel > 1 ? c.batteryLevel / 100 : c.batteryLevel;
  return (
    c.isCharging &&
    normLevel > 0.3 &&
    !c.isUserActive &&
    (c.thermalState === 'normal' || c.thermalState === 'warm')
  );
}

/**
 * 深い睡眠の未達理由を取得するヘルパー関数
 */
export function getDeepSleepUnmetReasons(c: BackgroundExecutionConditions): string[] {
  const reasons: string[] = [];
  if (!c.isCharging) {
    reasons.push('充電器に接続されていません (充電中が必要です)');
  }
  const normLevel = c.batteryLevel > 1 ? c.batteryLevel / 100 : c.batteryLevel;
  if (normLevel <= 0.3) {
    reasons.push(`バッテリー残量が不足しています (${Math.round(normLevel * 100)}% / 30%超が必要です)`);
  }
  if (c.isUserActive) {
    reasons.push('直近にユーザーのチャット操作・アプリ操作があります (アイドル待機中)');
  }
  if (c.thermalState === 'hot') {
    reasons.push('端末が高温です (hot: normalまたはwarmが必要です)');
  } else if (c.thermalState === 'critical') {
    reasons.push('端末温度が危険域です (critical)');
  }
  return reasons;
}

/**
 * 浅い睡眠の未達理由を取得するヘルパー関数
 */
export function getShallowSleepUnmetReasons(c: BackgroundExecutionConditions): string[] {
  const reasons: string[] = [];
  if (c.isUserActive) {
    reasons.push('直近にユーザーのチャット操作・アプリ操作があります');
  }
  if (c.thermalState === 'critical') {
    reasons.push('端末温度が危険域です (critical)');
  }
  return reasons;
}

/**
 * Android WorkManager & バックグラウンド自律処理サービス
 *
 * 設計思想 11. バックグラウンド自己対話と自律改善 (会話中ではなく深夜・充電中・Wi-Fi接続時に実行)
 * 設計思想 23. Androidネイティブと連携 (WorkManager, BatteryManager, NetworkCapabilities)
 * 設計思想「浅い睡眠 / 深い睡眠」による厳格な実行条件ゲート
 */
export class BackgroundWorkerService {
  private constraints: WorkManagerConstraints = {
    requiresCharging: true,
    requiresDeviceIdle: false, // 睡眠判定で厳格に制御
    requiresUnmeteredWifi: false, // 設計思想 Master v5.4 第19.6項: モバイル回線時も自律学習を許可 (既定false)
    batteryNotLow: true,
    nightTimeOnly: false,
  };

  private intervalMinutes: number = 60; // 変更前: 360 (Termux/PC常時運用向けに1時間ごとに緩和)
  private executionLogs: BackgroundTaskExecutionLog[] = [];
  private isRegistered: boolean = true;
  private isExecutingNow: boolean = false;
  private currentSleepState: 'idle' | 'shallow' | 'deep' = 'idle';
  private lastRunTimestamp: number = 0;
  private nextScheduledRunTimestamp: number = 0;

  // ハードウェア & 環境状態
  private batteryState = {
    level: 100, // 0 - 100
    charging: true,
    supported: false,
  };

  private thermalState: 'normal' | 'warm' | 'hot' | 'critical' = 'normal';

  private networkState = {
    isWifi: true,
    isOnline: true,
    type: 'wifi',
  };

  // ユーザーアクティビティ管理 (会話割り込み防止)
  private lastUserActivityTimestamp: number = 0;
  private isChatGenerating: boolean = false;
  private activeAbortController: AbortController | null = null;
  private idleTimer: any = null;
  private isUserIdle: boolean = false;
  private schedulerTimer: any = null;

  // チャット操作後のクールダウン時間 (設計思想 Master v5.4 第19.6項: 2分から1分へ短縮)
  private readonly USER_ACTIVE_COOLDOWN_MS = 1 * 60 * 1000;

  constructor() {
    this.loadState();
    this.initHardwareMonitors();
    this.initIdleDetector();
    this.scheduleNextRun();
    this.initNativeWorkManager();
    if (this.isRegistered) {
      nativeBackgroundService.start().catch(() => {});
    }
  }

  /**
   * Android WorkManager ネイティブブリッジ初期化
   * - ヘッドレスWebView / evaluateJavascript 用のグローバル受け口を登録
   * - Capacitor プラグインのイベントリスナーを接続
   * - Android環境ならWorkManagerに初期ジョブを登録
   */
  private initNativeWorkManager(): void {
    if (typeof window !== 'undefined') {
      // 1. グローバル受け口 (Headless WebView / evaluateJavascript)
      (window as any).mikiRunBackgroundCycle = async (
        triggerSource: 'manual' | 'periodic_scheduled' | 'android_intent' = 'android_intent'
      ) => {
        return this.runAutonomousBackgroundCycle(triggerSource);
      };

      // 2. Capacitor Plugin イベントリスナー経由のトリガー
      nativeWorkManagerService.setupTriggerListener(async (source) => {
        if (this.isExecutingNow) {
          systemLogger.info('SELF_IMPROVEMENT', 'WorkManager: Background cycle already executing, skipping trigger.');
          return;
        }
        systemLogger.info('SELF_IMPROVEMENT', `WorkManager: Triggered by native intent [${source}]`);
        // ネイティブ側から起動された場合、JS側のsetIntervalポーリング判定タイマーを再スケジュールして二重実行を防止
        this.scheduleNextRun();
        try {
          await this.runAutonomousBackgroundCycle(source);
        } catch (e) {
          console.warn('WorkManager autonomous cycle failed:', e);
        }
      });
    }

    // 3. Android ネイティブ環境であれば WorkManager ジョブを同期
    if (this.isRegistered && nativeWorkManagerService.isAndroidNative()) {
      this.syncNativeWorkManagerSchedule();
    }
  }

  /**
   * WorkManager へのスケジュール同期
   */
  public async syncNativeWorkManagerSchedule(): Promise<void> {
    if (!nativeWorkManagerService.isAndroidNative()) return;
    try {
      if (this.isRegistered) {
        await nativeWorkManagerService.schedule(this.intervalMinutes, this.constraints);
      } else {
        await nativeWorkManagerService.cancel();
      }
    } catch (e) {
      console.warn('Failed to sync WorkManager schedule with native layer:', e);
    }
  }

  private loadState(): void {
    if (typeof storageService === 'undefined') return;
    try {
      const savedConstraints = storageService.getItem(WORK_MANAGER_CONSTRAINTS_KEY);
      if (savedConstraints) this.constraints = JSON.parse(savedConstraints);

      const savedLogs = storageService.getItem(WORK_MANAGER_LOGS_KEY);
      if (savedLogs) this.executionLogs = JSON.parse(savedLogs);

      const savedConfig = storageService.getItem(WORK_MANAGER_CONFIG_KEY);
      if (savedConfig) {
        const parsed = JSON.parse(savedConfig);
        this.intervalMinutes = parsed.intervalMinutes || 360;
        this.lastRunTimestamp = parsed.lastRunTimestamp || 0;
      }
    } catch (e) {
      console.warn('Failed to load WorkManager state:', e);
    }
  }

  private saveState(): void {
    if (typeof storageService === 'undefined') return;
    try {
      storageService.setItem(WORK_MANAGER_CONSTRAINTS_KEY, JSON.stringify(this.constraints));
      storageService.setItem(WORK_MANAGER_LOGS_KEY, JSON.stringify(this.executionLogs.slice(-50)));
      storageService.setItem(
        WORK_MANAGER_CONFIG_KEY,
        JSON.stringify({
          intervalMinutes: this.intervalMinutes,
          lastRunTimestamp: this.lastRunTimestamp,
        })
      );
    } catch (e) {
      console.warn('Failed to save WorkManager state:', e);
    }
  }

  /**
   * Battery API & Network API モニタリング
   */
  private initHardwareMonitors(): void {
    // 1. Battery Status
    if (typeof navigator !== 'undefined' && 'getBattery' in navigator) {
      (navigator as any)
        .getBattery()
        .then((battery: any) => {
          this.batteryState.supported = true;
          this.batteryState.level = Math.round(battery.level * 100);
          this.batteryState.charging = battery.charging;

          battery.addEventListener('chargingchange', () => {
            this.batteryState.charging = battery.charging;
            systemLogger.info('SELF_IMPROVEMENT', `WorkManager: 充電状態変化 -> ${battery.charging ? '充電中' : '放電中'}`);
            // 充電が外れた場合、実行中の深い睡眠処理があれば安全に中断フラグを立てる
            if (!battery.charging && this.currentSleepState === 'deep') {
              this.abortDeepSleepExecution('充電器が切断されたため深い睡眠処理を安全に中断しました');
            }
          });

          battery.addEventListener('levelchange', () => {
            this.batteryState.level = Math.round(battery.level * 100);
            if (this.batteryState.level <= 30 && this.currentSleepState === 'deep') {
              this.abortDeepSleepExecution('バッテリー残量が30%以下に低下したため深い睡眠処理を中断しました');
            }
          });
        })
        .catch(() => {
          this.batteryState.supported = false;
        });
    }

    // 2. Network Information
    if (typeof navigator !== 'undefined') {
      this.networkState.isOnline = navigator.onLine;
      if (typeof window !== 'undefined') {
        window.addEventListener('online', () => (this.networkState.isOnline = true));
        window.addEventListener('offline', () => (this.networkState.isOnline = false));
      }

      const conn = (navigator as any).connection || (navigator as any).mozConnection || (navigator as any).webkitConnection;
      if (conn) {
        this.networkState.type = conn.type || conn.effectiveType || 'wifi';
        this.networkState.isWifi = conn.type === 'wifi' || conn.effectiveType === '4g' || !conn.saveData;
      }
    }

    // 3. Thermal State Monitoring (設計思想 42章 & 59章 / 指示書 SECTION 7 提案B)
    // Web標準ブラウザ環境では端末温度APIが直接露出していないため、
    // 自作Android APK/WebViewのJavaScriptInterface (AndroidThermalBridge / AndroidBridge)、
    // または window のカスタムイベント 'android_thermal_changed' / 'updateAndroidThermal' を通じて実温度を受け取ります。
    // ブリッジが存在しない環境では、テストUIによる手動シミュレーションに安全にフォールバックします。
    if (typeof window !== 'undefined') {
      try {
        const bridge = (window as any).AndroidThermalBridge || (window as any).AndroidBridge;
        if (bridge && typeof bridge.getBatteryTemperature === 'function') {
          const rawTemp = Number(bridge.getBatteryTemperature());
          if (!isNaN(rawTemp) && rawTemp > 0) {
            const celsius = rawTemp > 100 ? rawTemp / 10 : rawTemp;
            this.updateFromTemperatureCelsius(celsius);
          }
        }
      } catch (e) {}

      // Androidネイティブ層またはテストスクリプトからのイベント通知リスナー
      window.addEventListener('android_thermal_changed', (event: any) => {
        const detail = event?.detail;
        if (typeof detail === 'number') {
          const celsius = detail > 100 ? detail / 10 : detail;
          this.updateFromTemperatureCelsius(celsius);
        } else if (typeof detail === 'string' && ['normal', 'warm', 'hot', 'critical'].includes(detail)) {
          this.setThermalState(detail as any);
        } else if (detail && typeof detail.temperature === 'number') {
          const raw = detail.temperature;
          const celsius = raw > 100 ? raw / 10 : raw;
          this.updateFromTemperatureCelsius(celsius);
        }
      });

      // グローバルブリッジ関数を公開 (Android WebView の evaluateJavascript から直接呼び出し可能)
      (window as any).updateAndroidThermal = (tempOrState: number | string) => {
        if (typeof tempOrState === 'number') {
          const celsius = tempOrState > 100 ? tempOrState / 10 : tempOrState;
          this.updateFromTemperatureCelsius(celsius);
        } else if (typeof tempOrState === 'string' && ['normal', 'warm', 'hot', 'critical'].includes(tempOrState)) {
          this.setThermalState(tempOrState as any);
        }
      };
      (window as any).setThermalState = (state: 'normal' | 'warm' | 'hot' | 'critical') => {
        this.setThermalState(state);
      };
    }
  }

  /**
   * ユーザー無操作（アイドル）検出
   */
  private initIdleDetector(): void {
    if (typeof window === 'undefined') return;
    const resetIdle = () => {
      this.isUserIdle = false;
      this.lastUserActivityTimestamp = Date.now();
      clearTimeout(this.idleTimer);
      // 45秒間操作がなければアイドルとみなす
      this.idleTimer = setTimeout(() => {
        this.isUserIdle = true;
      }, 45000);
    };

    window.addEventListener('mousemove', resetIdle, { passive: true });
    window.addEventListener('keydown', resetIdle, { passive: true });
    window.addEventListener('touchstart', resetIdle, { passive: true });
    resetIdle();
  }

  /**
   * ユーザーがチャット操作（送信、入力など）を行ったことを記録
   * 会話中・直後の割り込みを完全防止
   */
  public recordUserActivity(): void {
    this.lastUserActivityTimestamp = Date.now();
    this.isUserIdle = false;
    if (this.currentSleepState === 'deep') {
      this.abortDeepSleepExecution('ユーザーのチャット操作が検知されたため、深い睡眠処理を安全に中断しました');
    }
  }

  /**
   * チャット推論中ステータスの設定 (会話中の割り込み防止)
   */
  public setChatGenerating(isGenerating: boolean): void {
    this.isChatGenerating = isGenerating;
    if (isGenerating) {
      this.recordUserActivity();
      if (this.currentSleepState === 'deep' || this.isExecutingNow) {
        this.abortDeepSleepExecution('チャット応答生成が開始されたため、バックグラウンド重処理を直ちに中断しました');
      }
    }
  }

  /**
   * 深い睡眠処理の安全な中断処理
   */
  private abortDeepSleepExecution(reason: string): void {
    if (this.activeAbortController && !this.activeAbortController.signal.aborted) {
      systemLogger.warn('SELF_IMPROVEMENT', `⏸ [Gate] ${reason}`);
      this.activeAbortController.abort(reason);
    }
  }

  /**
   * 現在の実行条件 (BackgroundExecutionConditions) を取得
   */
  public getExecutionConditions(): BackgroundExecutionConditions {
    const now = Date.now();
    const timeSinceLastActivity = now - this.lastUserActivityTimestamp;
    const isRecentlyActive = timeSinceLastActivity < this.USER_ACTIVE_COOLDOWN_MS;
    const isUserActive = this.isChatGenerating || isRecentlyActive || !this.isUserIdle;

    return {
      isCharging: this.batteryState.charging,
      batteryLevel: this.batteryState.level / 100, // 0 - 1
      isUserActive,
      thermalState: this.thermalState,
    };
  }

  private scheduleNextRun(): void {
    const nextRun = Date.now() + this.intervalMinutes * 60 * 1000;
    this.nextScheduledRunTimestamp = nextRun;

    if (this.schedulerTimer) clearInterval(this.schedulerTimer);
    // 30秒ごとにバックグラウンド実行条件をポーリング検査
    this.schedulerTimer = setInterval(() => {
      this.checkAndTriggerScheduledWork();
    }, 30000);
  }

  /**
   * 定期ジョブの実行条件判定 (JS側 setInterval)
   * ネイティブ側 WorkManager との二重実行を防止
   */
  private async checkAndTriggerScheduledWork(): Promise<void> {
    if (!this.isRegistered || this.isExecutingNow) return;

    // ネイティブ側 Worker が既に稼働中か確認し、二重実行を排他
    if (nativeWorkManagerService.isAndroidNative()) {
      try {
        const nativeStatus = await nativeWorkManagerService.getStatus();
        if (nativeStatus.isWorkerExecuting) {
          systemLogger.info('SELF_IMPROVEMENT', 'Native WorkManager is currently executing. Pausing JS setInterval trigger.');
          this.scheduleNextRun();
          return;
        }
      } catch (e) {}
    }

    const now = Date.now();
    const isDue = now >= this.nextScheduledRunTimestamp;
    if (!isDue) return;

    // 浅い睡眠または深い睡眠のどちらかが実行可能か判定
    const conditions = this.getExecutionConditions();
    const canShallow = canRunShallowSleep(conditions);
    const canDeep = canRunDeepSleep(conditions);

    if (!canShallow && !canDeep) {
      return; // 実行条件未達のため延期
    }

    this.runAutonomousBackgroundCycle('periodic_scheduled').catch((err) => {
      console.warn('Scheduled autonomous cycle failed:', err);
    });
  }

  /**
   * WorkManager 制約評価 (従来のAPI互換 & 条件チェック)
   */
  public evaluateConstraints(): { passed: boolean; reasons: string[] } {
    const conditions = this.getExecutionConditions();
    const deepReasons = getDeepSleepUnmetReasons(conditions);
    const shallowReasons = getShallowSleepUnmetReasons(conditions);

    // 少なくとも浅い睡眠が動くかどうか
    const passed = canRunShallowSleep(conditions);

    return {
      passed,
      reasons: deepReasons,
    };
  }

  /**
   * 自律バックグラウンド処理サイクルを実行
   * 設計思想「浅い睡眠 / 深い睡眠」による厳格な2段階ゲート制御
   *
   * [浅い睡眠]: 記憶統合・知識グラフ構築・LoRA重複除去・スキル抽出 (軽量)
   * [深い睡眠]: 自己対話テスト・A/Bベンチマーク・回帰ベンチマーク・教材生成 (重推論)
   */
  public async runAutonomousBackgroundCycle(
    triggerSource: 'manual' | 'periodic_scheduled' | 'android_intent' = 'manual',
    context?: {
      memories?: MemoryItem[];
      onUpdateMemories?: (updater: (prev: MemoryItem[]) => MemoryItem[]) => void;
      persona?: PersonaConfig;
      messages?: ChatMessage[];
    }
  ): Promise<BackgroundTaskExecutionLog> {
    if (this.isExecutingNow) {
      throw new Error('バックグラウンドタスクが既に実行中です');
    }

    const initialConditions = this.getExecutionConditions();

    // 手動実行以外の定期スケジュール時は、最低限浅い睡眠条件を満たしている必要がある
    if (triggerSource !== 'manual' && !canRunShallowSleep(initialConditions)) {
      const reasons = getShallowSleepUnmetReasons(initialConditions);
      throw new Error(`浅い睡眠の実行条件を満たしていません: ${reasons.join(', ')}`);
    }

    this.isExecutingNow = true;
    this.currentSleepState = 'shallow';
    this.activeAbortController = new AbortController();
    const abortSignal = this.activeAbortController.signal;

    const startTime = Date.now();
    const logId = 'bg_' + startTime + '_' + Math.random().toString(36).substring(2, 6);

    systemLogger.info('SELF_IMPROVEMENT', `⚡ WorkManager 自律処理開始 [Trigger: ${triggerSource}]`);

    let consolidatedCount = 0;
    let graphLinksCreated = 0;
    let simulatedCount = 0;
    const weaknessFound: string[] = [];
    let abTestsRunCount = 0;
    let regressionReport: RegressionSuiteRunReport | null = null;
    let deepSleepExecuted = false;
    let deepSleepSkippedReason: string | null = null;
    let syntheticCreatedCount = 0;

    try {
      // ==========================================
      // PHASE 1: 浅い睡眠 (Shallow Sleep)
      // ==========================================
      systemLogger.info('SELF_IMPROVEMENT', '🌙 [浅い睡眠] 記憶整理 & 重複除去 & スキル抽出を開始');

      // Step 0: 設計思想 Master v5.4 第19.4項 埋め込み健全性軽量チェック
      try {
        const embeddingHealth = await embeddingService.checkHealth();
        if (embeddingHealth.status === 'degraded_fallback') {
          systemLogger.warn(
            'SELF_IMPROVEMENT',
            `[19.4項 埋め込み縮退検知] 連続${embeddingHealth.consecutiveDegradedCount}回オフライン。疎ベクトルフォールバック中`
          );
        }
      } catch (healthErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '埋め込みヘルスチェック中に例外が発生しました', healthErr);
      }

      // Step 1: 記憶の統合・整理 & 知識グラフリンク構築
      if (context?.memories && context?.onUpdateMemories) {
        const mems = context.memories;
        const activeMems = mems.filter((m) => m.active !== false);

        // 設計思想 8章: 長期記憶の自律監査とライフサイクル整理 (SUPERSEDED・EXPIRED・未検証の選別)
        const memoryAudit = longTermMemoryService.auditAndConsolidateMemories(mems);

        context.onUpdateMemories((prev) => {
          return memoryAudit.updatedMemories.map((target) => {
            if (target.prerequisiteMemoryIds && target.prerequisiteMemoryIds.length > 0) {
              return target;
            }
            const targetVec = target.domainVector || calculateDomainVector(target.content);
            const related = activeMems
              .filter((other) => other.id !== target.id)
              .map((other) => {
                const otherVec = other.domainVector || calculateDomainVector(other.content);
                const sim = calculateCosineSimilarity(targetVec, otherVec);
                return { other, sim };
              })
              .filter((res) => res.sim > 0.65)
              .slice(0, 2);

            if (related.length > 0) {
              graphLinksCreated++;
              return {
                ...target,
                relatedMemoryIds: Array.from(new Set([...(target.relatedMemoryIds || []), ...related.map((r) => r.other.id)])),
              };
            }
            return target;
          });
        });
        consolidatedCount = activeMems.length;
        systemLogger.info(
          'SELF_IMPROVEMENT',
          `[8章 記憶監査] 長期記憶=${memoryAudit.longTermCount}件, 置換済み=${memoryAudit.supersededCount}件, 期限切れ=${memoryAudit.expiredCount}件, 未検証=${memoryAudit.unverifiedCount}件`
        );
      }

      // Step 2: DPO / LoRA 学習サンプルの本格クリーンアップ・重複除去
      const cleanupResult = selfImprovementService.cleanAndDeduplicateSamples();

      // Step 3: 会話ログからのスキル自動抽出 & 昇格評価
      let extractedSkillsCount = 0;
      if (context?.messages && context.messages.length > 0) {
        const newSkills = skillsService.autoExtractSkillsFromHistory(context.messages);
        extractedSkillsCount = newSkills.length;
      }
      const skillPromo = skillsService.evaluateAllSkillsPromotion();

      // Step 3.5: 設計思想 32章 能力ギャップレジストリ監査
      const capabilityGaps = capabilityGapService.getAllGaps();
      const capabilityProfiles = capabilityGapService.getAllProfiles();
      const weakCapabilities = capabilityProfiles.filter((p) => p.state === 'WEAK');

      // Step 3.6: 設計思想 46章 能力プラグイン権限整合性監査 (自動権限拡大の防止)
      const plugins = capabilityPluginService.getAllPlugins();
      let unconsentedPluginsCount = 0;
      plugins.forEach((p) => {
        if (p.status === 'TESTED' || p.status === 'CANDIDATE') {
          unconsentedPluginsCount++;
        }
      });

      // Step 3.7: 設計思想 7.3節 自己成長ループ自動化 (浅い睡眠: 未来質問シミュレータ & 自動レッドチーム)
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        const shallowHardening = autonomousHardeningService.runAutonomousHardeningCycle('shallow', { signal: abortSignal });
        if (shallowHardening.futureResults.length > 0 || shallowHardening.redTeamResults.length > 0) {
          weaknessFound.push(
            `[自己成長ループ(浅い睡眠)] 未来質問${shallowHardening.futureResults.length}件, RedTeam${shallowHardening.redTeamResults.length}件実行` +
            (shallowHardening.circuitBreakerSkipped.length > 0 ? ` (連続FAIL抑止: ${shallowHardening.circuitBreakerSkipped.join(', ')})` : '')
          );
        }
      } catch (hardeningErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '浅い睡眠での自己成長ループ(Hardening)実行中に例外が発生しました', hardeningErr);
      }

      // 予測誤差学習の記録 (設計思想 1.1節: 実際に何らかの作業が発生したサイクルでのみ記録)
      const shallowWorkCount = consolidatedCount + graphLinksCreated + extractedSkillsCount + cleanupResult.removedDuplicates;
      if (shallowWorkCount > 0) {
        const shallowActualMs = Date.now() - startTime;
        const shallowPredictedMs = Math.max(100, shallowWorkCount * 25);
        autonomousHardeningService.recordPredictionError({
          actionName: 'autonomous_shallow_sleep_consolidation',
          predictedDurationMs: shallowPredictedMs,
          actualDurationMs: shallowActualMs,
          predictedMemoryMb: 8,
          actualMemoryMb: 8.5,
          predictedErrors: [],
          actualErrors: [],
        });
      }

      // Step 3.8: 指示書 4: 会話癖の自己統計集計 (質問率・平均返信長・訂正率・話題変更率)
      try {
        conversationStrategyService.generateConversationHabitsReport(context?.messages);
      } catch (habitErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '会話癖レポート生成中に例外が発生しました', habitErr);
      }

      systemLogger.info(
        'SELF_IMPROVEMENT',
        `✓ [浅い睡眠完了] 記憶整理(${consolidatedCount}件), グラフ接続(+${graphLinksCreated}件), サンプル重複除外(${cleanupResult.removedDuplicates}件), スキル抽出(+${extractedSkillsCount}件), 能力ギャップ(${capabilityGaps.length}件/WEAK:${weakCapabilities.length}件), プラグイン承認待ち(${unconsentedPluginsCount}件)`
      );

      // ==========================================
      // PHASE 2: 深い睡眠 (Deep Sleep) ゲート検査
      // ==========================================
      // 割り込みチェック
      if (abortSignal.aborted) {
        throw new Error(`中断されました: ${abortSignal.reason || 'ユーザー操作'}`);
      }

      const currentConditions = this.getExecutionConditions();
      const allowDeepSleep = triggerSource === 'manual' ? true : canRunDeepSleep(currentConditions);

      if (!allowDeepSleep) {
        const unmetReasons = getDeepSleepUnmetReasons(currentConditions);
        deepSleepSkippedReason = unmetReasons.join(', ');
        systemLogger.info(
          'SELF_IMPROVEMENT',
          `💤 [深い睡眠スキップ] 実行条件を満たさないため重い処理を省略します: ${deepSleepSkippedReason}`
        );
      } else {
        // 深い睡眠を開始
        this.currentSleepState = 'deep';
        deepSleepExecuted = true;
        systemLogger.info('SELF_IMPROVEMENT', '🌌 [深い睡眠] 自己対話テスト・A/Bテスト・回帰ベンチマークを開始');

        // Step 4: 自己対話による弱点シミュレーション & 失敗診断
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        const errors = worldModelService.getErrorRecords();
        const highErrors = errors.filter((e) => e.predictionError.errorMagnitude >= 0.35);

        if (highErrors.length > 0) {
          simulatedCount = Math.min(highErrors.length, 3);
          highErrors.slice(0, 3).forEach((err) => {
            const cat = err.predictionError.errorCategory;
            const prompt = err.prediction.userPrompt;
            weaknessFound.push(`[${cat}] 「${prompt.substring(0, 20)}...」への逸脱を検証 ➔ 修正境界を追加`);

            if (err.predictionError.errorCategory === 'constraint_violation' || err.actualOutcome.hasToneViolation) {
              const failureCheck = selfImprovementService.recordOrCheckFailureRecurrence({
                prompt,
                category: cat,
                reason: 'ロボット的敬語の混入・制約逸脱',
              });

              if (failureCheck.isActionable) {
                const experienceId = `exp_bg_failure_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
                const failureLogId = `fail_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
                experienceLinkService.getOrCreateLink(experienceId, 'autonomous_cycle', `再発失敗検知: ${prompt.slice(0, 30)}`);
                experienceLinkService.linkEntity(experienceId, 'failureLog', failureLogId);

                capabilityGapService.recordGap({
                  description: `[再発弱点検知: ${failureCheck.recurrenceCount}回] ${prompt.slice(0, 40)}: ロボット的敬語の混入・制約逸脱`,
                  gap_type: 'failure',
                  capabilityId: 'cap_direct_answer',
                  impact: 'HIGH',
                  current_workaround: '親友口調制約を回答計画(AnswerPlan)に決定論的に反映',
                  candidate_solution: 'タメ口ペルソナ制約テンプレートの適用とCSP制約充足チェックの厳格化',
                  samplePrompt: prompt,
                  failureLogId,
                  experienceId,
                });
                selfImprovementService.markFailurePromoted(failureCheck.patternKey);
                weaknessFound.push(`[再発弱点昇格] 「${prompt.substring(0, 15)}...」が${failureCheck.recurrenceCount}回再現 ➔ 能力ギャップとして登録・改善提案へ移行`);
              } else {
                weaknessFound.push(`[一過性失敗ガード] 「${prompt.substring(0, 15)}...」初回検知 (再現待機: ${failureCheck.recurrenceCount}/2回) ➔ 改善提案保留`);
              }
            }
          });
        } else {
          simulatedCount = 1;
          weaknessFound.push('基本タメ口ペルソナ維持・境界テスト ➔ 逸脱なし(OK)');
        }

        // Step 5: プロンプトA/Bテストのバックグラウンド静的シミュレーション
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        try {
          const abResult = await selfImprovementService.runPromptABBenchmark(
            'こんにちは！今日何してた？',
            {
              name: '親友ペルソナA',
              systemPrompt: 'あなたは親友のみきだよ。タメ口で明るく自然な日本語で話してね。',
            },
            {
              name: '丁寧アシスタントB',
              systemPrompt: 'あなたはアシスタントです。親しみやすく返信してください。',
            }
          );
          if (abResult) {
            abTestsRunCount = 1;
          }
        } catch {
          // スキップ
        }

        // Step 6: 自律回帰ベンチマーク評価
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        try {
          if (!regressionBenchmarkService.isBusy()) {
            const isNativeReady = false;
            const isWebReady = false;
            if (isNativeReady || isWebReady) {
              regressionReport = await regressionBenchmarkService.runFullSuite();
              if (regressionReport.regressionsCount > 0 || regressionReport.failedTests > 0) {
                weaknessFound.push(
                  `[回帰劣化検知] 自律ベンチマークで退行${regressionReport.regressionsCount}件 / 失敗${regressionReport.failedTests}件を検出 (総合スコア: ${regressionReport.overallScore}点)`
                );
              }
            } else {
              systemLogger.info('SELF_IMPROVEMENT', '自律回帰テスト: 推論モデル未ロードのためスキップ');
            }
          }
        } catch (benchErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '自律回帰ベンチマーク実行中に例外が発生しました', benchErr);
        }

        // Step 6.5: 端末内 合成教材生成パイプライン (設計思想 33節・53節 フェーズ7)
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        syntheticCreatedCount = 0;
        try {
          const synSummary = await syntheticDataService.runDeepSleepSyntheticCycle();
          if (synSummary && synSummary.approvedCount > 0) {
            syntheticCreatedCount = synSummary.approvedCount;
            weaknessFound.push(
              `[合成学習データ工場] 弱点「${synSummary.weaknessCategory}」に偏らせた練習問題を生成 ➔ ${synSummary.approvedCount}件の高品質教材を自動登録`
            );
          }
        } catch (synErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '合成教材生成パイプライン実行中に例外が発生しました', synErr);
        }

        // Step 6.6: 設計思想 16章 仮想学習試験 & LoRA検討の発動条件判定
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        try {
          const loraAssessment = virtualTrainingService.evaluateLoraTriggerCondition();
          if (loraAssessment.triggered) {
            weaknessFound.push(
              `[16章 LoRA発動条件検知] 言い換え再発または能力停滞を検出 ➔ 仮想学習シミュレーションを実行`
            );
            // 仮想学習試験の実行 (LoRA不要判定を優先検証)
            const trial = await virtualTrainingService.runVirtualTrainingTrial('cap_correction');
            weaknessFound.push(`[仮想学習判定: ${trial.verdict}] ${trial.verdictDetails}`);
          } else {
            systemLogger.info(
              'SELF_IMPROVEMENT',
              `[16章 仮想学習監査] 回答骨格(9章)・検索(8章)で制御優位。LoRA発動条件未達(DISABLED維持)`
            );
          }
        } catch (vtErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '仮想学習監査中に例外が発生しました', vtErr);
        }

        // Step 6.7: 設計思想 11章 睡眠ゲート ＆ 20章 遅延外部教師リクエストバッチ処理
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        let processedTeacherBatchCount = 0;
        try {
          const queue = teacherRequestService.getDelayedQueue();
          const pendingItems = queue.filter((q) => q.status === 'PENDING');
          if (pendingItems.length > 0) {
            systemLogger.info(
              'SELF_IMPROVEMENT',
              `🌌 [11章 深い睡眠バッチ] 待機中の外部教師遅延要請 (${pendingItems.length}件) のバッチ処理を開始`
            );
            const batchResult = await teacherRequestService.processDelayedTeacherQueue(3);
            processedTeacherBatchCount = batchResult.succeededCount;
            if (batchResult.processedCount > 0) {
              weaknessFound.push(
                `[11章/20章 遅延教師バッチ] 待機要請${batchResult.processedCount}件処理 ➔ 成功${batchResult.succeededCount}件 / 失敗${batchResult.failedCount}件 (回答骨格・教材を自動反映)`
              );
            }
          }
        } catch (teacherBatchErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '遅延教師バッチ処理中に例外が発生しました', teacherBatchErr);
        }

        // Step 6.8: 設計思想 Master v5.0 第2章③ & 第9章 自発思考モード (Autonomous Thought on Working Agenda)
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        try {
          const homeworks = workingAgendaService.getHomeworkForAutonomousThought();
          if (homeworks.length > 0) {
            systemLogger.info(
              'SELF_IMPROVEMENT',
              `🧠 [第9章 自発思考モード] Working Agenda から${homeworks.length}件の未解決宿題を検知。自発考察を実行します。`
            );
            for (const hw of homeworks.slice(0, 2)) {
              if (abortSignal.aborted) break;
              const thoughtPrompt = `あなたは自律学習中のAI「みき」です。ユーザーとの会話で未解決・宿題となっている以下の課題について、最善の解決方針や知見を自発的に考察し、結論をまとめてください。\n\n【課題トピック】: ${hw.topic}\n【未解決事項】: ${hw.unresolvedQuestions.join(', ')}\n【これまでの合意】: ${hw.recentDecisions.join(', ')}`;
              
              let thoughtResult = '';
              const messages: Array<{ role: 'system' | 'user' | 'assistant'; content: string }> = [
                { role: 'user', content: thoughtPrompt },
              ];
              if (false && '') {
                for await (const chunk of deterministicRuntimeService.streamDeterministicChat(messages, { max_tokens: 256, temperature: 0.5 })) {
                  thoughtResult += chunk;
                }
              } else if (false) {
                for await (const chunk of deterministicRuntimeService.streamChat(messages, { max_tokens: 256, temperature: 0.5 })) {
                  thoughtResult += chunk;
                }
              }

              if (thoughtResult && thoughtResult.trim().length > 20) {
                const decisionSummary = thoughtResult.slice(0, 80).replace(/[\n\r]/g, ' ');
                workingAgendaService.resolveAgenda(hw.id, `自発思考による考察完了: ${decisionSummary}`);
                weaknessFound.push(`[自発思考] 宿題「${hw.topic}」について自律考察し方針を確定・保存`);
              }
            }
          }
        } catch (thoughtErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '自発思考モード実行中に例外が発生しました', thoughtErr);
        }

        // Step 6.9: 設計思想 Master v5.0 第13章2節 非会話時・深い睡眠時の自律Web検索能動学習
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        try {
          const searchConfig = unifiedWebResearchService.getConfig();
          if (searchConfig.enabled && searchConfig.idleSearchEnabled) {
            systemLogger.info(
              'SELF_IMPROVEMENT',
              '🌐 [第13章 能動Web検索学習] 非会話時の自発的Web検索学習を開始します...'
            );
            const searchLearningResult = await unifiedWebResearchService.performIdleAutonomousLearning(abortSignal);
            if (searchLearningResult.learnedCount > 0) {
              weaknessFound.push(
                `[自律Web学習] ${searchLearningResult.learnedCount}件の課題について最新知見を調査・長期記憶と教材データセットへ反映 (${searchLearningResult.queriesInvestigated.join(', ')})`
              );
            }
          }
        } catch (searchLearnErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '自律Web検索学習中に例外が発生しました', searchLearnErr);
        }

        // Step 6.10: 設計思想 Master v5.4 第19章 放置型自律進化エンジン (反省・知恵蒸留・宿題解決・弱点ドリル)
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        try {
          systemLogger.info('SELF_IMPROVEMENT', '🌱 [第19章 放置型自律進化] 反省・定石蒸留・宿題解決パイプラインを実行中...');
          const evolutionReport = await autonomousEvolutionService.runIdleEvolutionCycle(abortSignal);
          if (evolutionReport.growthHighlights.length > 0) {
            weaknessFound.push(...evolutionReport.growthHighlights);
          }
        } catch (evoErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '放置型自律進化サイクル実行中に例外が発生しました', evoErr);
        }

        // Step 6.11: 設計思想 Master v5.4 第19章 記憶の間隔反復定着・鮮度再検証・埋め込み健全性監視
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        try {
          systemLogger.info('SELF_IMPROVEMENT', '🧠 [第19章 記憶監査] 間隔反復定着・鮮度再検証・埋め込み復旧バッチを実行中...');
          const auditRecord = await memoryAuditService.runFullAuditCycle(abortSignal);
          if (auditRecord.spacedRecall.reinforcedCount > 0) {
            weaknessFound.push(
              `[19.2 間隔反復] ${auditRecord.spacedRecall.reinforcedCount}件の休眠重要記憶を自律再想起・定着補強`
            );
          }
          if (auditRecord.freshness.diffsDetected > 0) {
            weaknessFound.push(
              `[19.3 鮮度再検証] ${auditRecord.freshness.diffsDetected}件の記憶に最新Web調査差分を検知し更新候補を保持`
            );
          }
        } catch (auditErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '記憶の間隔反復・鮮度再検証サイクル中に例外が発生しました', auditErr);
        }
        // Step 6.12: 設計思想 Master v5.5 第21章 保存容量配分 (Galaxy S25 60GB計画) ＆ 第24章 モデル実測データ駆動型退役思考 (モデル重み不変性)
        if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
        try {
          systemLogger.info('SELF_IMPROVEMENT', '💾 [第21章/第24章] 容量管理・一時データ自動クリーンアップ ＆ モデル退役思考を実行中...');
          const cleanupResult = storagePlanningService.runDeduplicationAndCleanup();
          if (cleanupResult.removedCount > 0) {
            weaknessFound.push(
              `[21章/24章 容量・モデル管理] ${cleanupResult.removedCount}件の重複・一時ファイルを安全除去し、${cleanupResult.spaceReclaimedMb.toFixed(1)}MBの容量を回収`
            );
          }
          if (cleanupResult.modelReasoningSummary) {
            weaknessFound.push(`[24章 モデル自律退役思考] ${cleanupResult.modelReasoningSummary}`);
          }
        } catch (cleanupErr: any) {
          systemLogger.warn('SELF_IMPROVEMENT', '容量自動整理・モデル退役思考サイクル中に例外が発生しました', cleanupErr);
        }
      }

      // Step 6.12.5: 失敗・陳腐化した能力の自動再検証
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        const revalidation = await autonomousRevalidationLoopService.run({ limit: deepSleepExecuted ? 8 : 3, signal: abortSignal });
        // Step 6.12.6: 失敗したRemediationを再調査へ戻すサービスはEventBus常駐。
        // dispatchQueuedは既存Runner境界を維持し、ここでは再投入待ちを進める。
        void remediationFailureRecoveryService;
        const remediationDispatch = remediationExecutionCoordinatorService.dispatchQueued(deepSleepExecuted ? 8 : 3);
        const remediationSubmitted = remediationDispatch.reduce((n, r) => n + r.submitted.length, 0);
        if (remediationSubmitted) systemLogger.info('TOOLS', `[自動Remediation実行投入] ${remediationSubmitted}件をExternal RunnerへSUBMITTED`);
        if (revalidation.staleCapabilities.length > 0) {
          weaknessFound.push(`[自動再検証] 陳腐化/低信頼能力${revalidation.staleCapabilities.length}件を再調査 → Web研究${revalidation.researched}件 / 解決${revalidation.resolved}件`);
        }
      } catch (revalidationErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '自動再検証サイクルをスキップしました', revalidationErr);
      }

      // Step 6.12.7: 設計思想 7.3節 自己成長ループ自動化 (深い睡眠: 未来質問 & 自動レッドチーム拡張実行)
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        if (deepSleepExecuted) {
          const deepHardening = autonomousHardeningService.runAutonomousHardeningCycle('deep', { signal: abortSignal });
          if (deepHardening.futureResults.length > 0 || deepHardening.redTeamResults.length > 0) {
            weaknessFound.push(
              `[自己成長ループ(深い睡眠)] 未来質問${deepHardening.futureResults.length}件, RedTeam${deepHardening.redTeamResults.length}件拡張実行` +
              (deepHardening.circuitBreakerSkipped.length > 0 ? ` (連続FAIL抑止: ${deepHardening.circuitBreakerSkipped.join(', ')})` : '')
            );
          }

          // 深い睡眠での作業発生時のみ予測誤差を記録
          const deepWorkCount = simulatedCount + syntheticCreatedCount + abTestsRunCount;
          if (deepWorkCount > 0) {
            const deepActualMs = Date.now() - startTime;
            const deepPredictedMs = Math.max(500, deepWorkCount * 250);
            autonomousHardeningService.recordPredictionError({
              actionName: 'autonomous_deep_sleep_synthesis',
              predictedDurationMs: deepPredictedMs,
              actualDurationMs: deepActualMs,
              predictedMemoryMb: 35,
              actualMemoryMb: 38,
              predictedErrors: [],
              actualErrors: [],
            });
          }
        }
      } catch (hardeningDeepErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '深い睡眠での自己成長ループ(Hardening)実行中に例外が発生しました', hardeningDeepErr);
      }

      // Step 6.12.8: 第145章 仮想経験生成（実環境・実コードへ昇格しない）
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        const virtualCases = virtualExperienceGeneratorService.generateFromContracts(deepSleepExecuted ? 10 : 4);
        if (virtualCases.length) weaknessFound.push(`[仮想経験] ${virtualCases.length}件を生成。実Regressionへの自動昇格はしません。`);
      } catch (virtualErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '仮想経験生成をスキップしました', virtualErr);
      }

      // Step 6.12.9: 第157章 故障注入・回復力実証（仮想失敗のみ）
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        if (deepSleepExecuted) {
          const candidates = ['general.deterministic.execution','general.decision.analysis'];
          for (const componentId of candidates) {
            faultInjectionLabService.run({ componentId, environment: 'deterministic-runtime', fault: 'STALE_KNOWLEDGE' });
          }
          weaknessFound.push('[故障注入] 仮想失敗モデルで回復経路を検査');
        }
      } catch (faultErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '故障注入ラボをスキップしました', faultErr);
      }

      // Step 6.12.10: 第159/161章 仕様契約・知識半減期監査
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        const specAudit = specContractCompilerService.audit();
        if (specAudit.invalidated) {
          specContractCompilerService.compile();
          weaknessFound.push(`[仕様契約] 指示書変更を検知し、追跡可能な最小契約を再コンパイル`);
        }
        const due = knowledgeHalfLifeService.due(deepSleepExecuted ? 20 : 8);
        if (due.length) weaknessFound.push(`[知識半減期] ${due.length}件を再検証候補として優先付け`);
      } catch (specErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '仕様契約・知識半減期監査をスキップしました', specErr);
      }

      // Step 6.12.11: 第146/147/148/149/150/151/152/153/154/166/169/170 統合ガバナンス監査
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        frontierGovernanceService.verifyTopInvariants();
        frontierGovernanceService.attentionPlan();
        // 未知環境は最初から実操作へ進めず、現在の能力境界を再確認する。
        frontierGovernanceService.listEnvironments();
        if (deepSleepExecuted) {
          frontierGovernanceService.auditEvaluator({ subject: 'miki-autonomous-regression', freshness: 0.8, reproducibility: 0.9, representativeness: 0.7 });
        }
      } catch (governanceErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '認知多様性・評価ガバナンス・最上位安全監査をスキップしました', governanceErr);
      }

      // Step 6.12.12: 設計思想 9章/16章/19.2節/20章 縦(骨格)・横(言い回し)の自律成長ループ
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        systemLogger.info('SELF_IMPROVEMENT', '📐 [縦横自律成長] 骨格候補の未解決ログ観測 ＆ 表層バリエーションの弱点補強サイクルを実行中...');

        // 縦の成長: 未解決対話ログからの骨格候補抽出 (上限5件、3回観測強制ルールでVERIFIED昇格)
        const skeletonGrowth = answerPlanService.processUnresolvedConversationsForSkeletonGrowth(5);
        if (skeletonGrowth.processedCount > 0) {
          weaknessFound.push(
            `[縦(骨格)自律成長] 未対応対話ログから${skeletonGrowth.processedCount}件の骨格候補を観測処理 (正式昇格: ${skeletonGrowth.promotedCount}件)`
          );
        }

        // 横の成長: RecentUsageCacheの弱点検出 -> 変種生成 (機械変異 + Gemini) -> 意味保持検査 -> CANDIDATE->VERIFIED昇格 (上限5件)
        const variationGrowth = await surfaceVariationGrowthService.runAutonomousVariationGrowthCycle(5);
        if (variationGrowth.promotedCount > 0 || variationGrowth.totalGenerated > 0) {
          weaknessFound.push(
            `[横(言い回し)自律成長] 弱点検出カテゴリ${variationGrowth.weaknessDetected.length}件に対し、候補${variationGrowth.totalGenerated}件生成 (合格:${variationGrowth.passedCount}件, 破棄:${variationGrowth.rejectedCount}件, 正式昇格:${variationGrowth.promotedCount}件)`
          );
        }

        // --- 作業指示書 v20 & 自動成長強化: Web検索自律学習素材による縦(骨格)・横(言い回し)の自律成長ループ配線 ---
        // 歯止め緩和: 1サイクルあたりの自律Web検索 (弱点カテゴリに応じた複数クエリ・最大8件取得)
        const searchConfig = unifiedWebResearchService.getConfig();
        if (searchConfig.enabled && !abortSignal.aborted) {
          // 弱点カテゴリまたは未対応課題から検索トピックを特定 (最大3カテゴリからクエリ生成)
          const weaknesses = surfaceVariationGrowthService.detectWeaknessCategories(5);
          const topicsToSearch: string[] = [];

          if (weaknesses.length > 0) {
            for (const w of weaknesses.slice(0, 3)) {
              let t = '';
              if (w.categoryKey.includes('disaster') || w.categoryKey.includes('error')) {
                t = 'トラブルシューティング 障害対応 手順';
              } else if (w.categoryKey.includes('lead') || w.categoryKey.includes('step')) {
                t = '手順 説明 構成 ベストプラクティス';
              } else if (w.categoryKey.includes('greeting') || w.categoryKey.includes('polite')) {
                t = '丁寧な受け答え 会話 挨拶 マナー';
              } else {
                t = '対話 受け答え 丁寧な説明 手順';
              }
              if (!topicsToSearch.includes(t)) {
                topicsToSearch.push(t);
              }
            }
          }

          if (topicsToSearch.length === 0) {
            const gaps = capabilityGapService.getAllGaps().filter((g) => g.status === 'OPEN');
            if (gaps.length > 0) {
              topicsToSearch.push(`${gaps[0].capabilityId} 手順 ガイド`.slice(0, 40));
            } else {
              topicsToSearch.push('トラブルシューティング 手順 ガイド');
            }
          }

          for (const webTopic of topicsToSearch.slice(0, 2)) {
            if (abortSignal.aborted) break;

            // 1. 禁止トピック手動設定による事前チェック
            const bannedCheck = bannedTopicsConfigService.checkBanned(webTopic);
            if (bannedCheck.isBanned) {
              systemLogger.warn(
                'SELF_IMPROVEMENT',
                `🚫 [Web自律成長除外] クエリ「${webTopic}」は禁止トピック「${bannedCheck.matchedTopic}」に抵触するため検索をスキップしました`
              );
              continue;
            }

            systemLogger.info(
              'SELF_IMPROVEMENT',
              `🌐 [Web自律成長検索] クエリ「${webTopic}」で自律学習素材を取得中... (歯止め緩和: 最大8件取得)`
            );

            // 2. Web検索実行 (最大8件取得)
            const searchRes = await unifiedWebResearchService.executeSearch(webTopic, { maxResults: 8 });
            const searchResults = searchRes.results || [];

            systemLogger.info(
              'SELF_IMPROVEMENT',
              `🌐 [Web素材取得件数] クエリ:「${webTopic}」, 取得件数: ${searchResults.length}件`
            );

            if (searchResults.length > 0) {
              // 3. 縦(骨格)への還元: 検索結果から構造抽出 -> registerSkeletonFromWebObservation (WEB_OBSERVED, 3回観測昇格制)
              let webSkeletonProcessed = 0;
              let webSkeletonPromoted = 0;
              for (const r of searchResults.slice(0, 4)) {
                const skeletonCand = WebMaterialPatternExtractor.extractSkeletonStructuresFromWebText({
                  title: r.title,
                  snippet: r.snippet,
                  summary: searchRes.summary,
                  sourceQuery: webTopic,
                  sourceUrl: r.url,
                  provider: searchRes.provider,
                });

                if (skeletonCand) {
                  webSkeletonProcessed++;
                  const regResult = answerPlanService.registerSkeletonFromWebObservation(skeletonCand);
                  if (regResult && regResult.status === 'VERIFIED') {
                    webSkeletonPromoted++;
                  }
                }
              }

              // 4. 横(言い回し)への還元: 普遍的言い回し抽出 -> processWebMaterialForVariationGrowth (WEB_DERIVED, 意味保持検査合格のみ)
              const combinedSnippets = searchResults
                .map((r) => r.snippet)
                .filter(Boolean)
                .join('\n');
              let webVarResult = { processedCount: 0, passedCount: 0, rejectedCount: 0, promotedCount: 0 };
              if (combinedSnippets) {
                const surfacePatterns = WebMaterialPatternExtractor.extractSurfacePatternsFromWebText({
                  text: combinedSnippets,
                  sourceQuery: webTopic,
                  sourceUrl: searchResults[0]?.url || '',
                  provider: searchRes.provider,
                });

                if (surfacePatterns.length > 0) {
                  webVarResult = surfaceVariationGrowthService.processWebMaterialForVariationGrowth(surfacePatterns, 3);
                }
              }

              systemLogger.info(
                'SELF_IMPROVEMENT',
                `🌐✨ [Web自律成長結果] 骨格候補(WEB_OBSERVED): ${webSkeletonProcessed}件到達 (正式昇格: ${webSkeletonPromoted}件), 言い回し変種(WEB_DERIVED): ${webVarResult.processedCount}件到達 (合格: ${webVarResult.passedCount}件, 破棄: ${webVarResult.rejectedCount}件, 正式昇格: ${webVarResult.promotedCount}件)`
              );

              weaknessFound.push(
                `[Web素材自律成長] クエリ「${webTopic}」(${searchResults.length}件取得) より 縦(骨格WEB_OBSERVED): 候補${webSkeletonProcessed}件(昇格${webSkeletonPromoted}件), 横(言い回しWEB_DERIVED): 合格${webVarResult.passedCount}件(破棄${webVarResult.rejectedCount}件, 昇格${webVarResult.promotedCount}件)`
              );
            }
          }
        }
      } catch (growthErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '縦横自律成長サイクルの実行中に例外が発生しました', growthErr);
      }

      // Step 6.13: 自律成長司令塔
      // 現行ソース/能力/仕様を再監査し、PASSしたものだけを次の成長段階へ送る。
      let growthGovernorResult: Awaited<ReturnType<typeof autonomousGrowthGovernorService.runCycle>> | null = null;
      if (abortSignal.aborted) throw new Error('ユーザー操作により中断');
      try {
        growthGovernorResult = await autonomousGrowthGovernorService.runCycle({
          allowSelfCodeImprovement: deepSleepExecuted,
          signal: abortSignal,
        });
        weaknessFound.push(...growthGovernorResult.actions.map(a => `[自律成長司令塔] ${a}`));
        if (growthGovernorResult.blockedActions.length) {
          weaknessFound.push(...growthGovernorResult.blockedActions.map(a => `[自律成長保留] ${a}`));
        }
      } catch (growthErr: any) {
        systemLogger.warn('SELF_IMPROVEMENT', '自律成長司令塔をスキップしました', growthErr);
      }

      // Step 7: 学習教材の蓄積しきい値チェック
      const thresholdCheck = selfImprovementService.checkTrainingThreshold();

      const durationMs = Date.now() - startTime;
      const summaryText = deepSleepExecuted
        ? `自律サイクル完了 [深い睡眠]: 記憶整理(${consolidatedCount}件), グラフ接続(+${graphLinksCreated}件), 弱点検証(${simulatedCount}件), スキル抽出(+${extractedSkillsCount}件)${syntheticCreatedCount ? `, 合成教材(+${syntheticCreatedCount}件)` : ''}${regressionReport ? `, 回帰スコア(${regressionReport.overallScore}点)` : ''}`
        : `自律サイクル完了 [浅い睡眠のみ]: 記憶整理(${consolidatedCount}件), グラフ接続(+${graphLinksCreated}件), スキル抽出(+${extractedSkillsCount}件) (※深い睡眠保留: ${deepSleepSkippedReason || '条件未達'})`;

      const logRecord: BackgroundTaskExecutionLog = {
        id: logId,
        timestamp: Date.now(),
        taskType: 'autonomous_cycle',
        status: 'completed',
        durationMs,
        batteryLevel: this.batteryState.level,
        isCharging: this.batteryState.charging,
        isWifi: this.networkState.isWifi,
        summary: summaryText,
        details: {
          consolidatedMemoriesCount: consolidatedCount,
          graphLinksCreatedCount: graphLinksCreated,
          simulatedDialoguesCount: simulatedCount,
          cleanedDatasetSamplesCount: cleanupResult.afterCount,
          cleanedDuplicatesCount: cleanupResult.removedDuplicates,
          prunedLowQualityCount: cleanupResult.prunedLowQuality,
          skillsExtractedCount: extractedSkillsCount,
          skillsPromotedCount: skillPromo.promotedCount,
          abTestsRunCount,
          regressionBenchmarkScore: regressionReport ? regressionReport.overallScore : undefined,
          regressionReportId: regressionReport ? regressionReport.id : undefined,
          trainingThresholdReached: thresholdCheck.thresholdReached,
          trainingCurrentCount: thresholdCheck.currentCount,
          trainingTargetThreshold: thresholdCheck.threshold,
          syntheticGeneratedCount: syntheticCreatedCount,
          weaknessFound,
          autonomousGrowthCycleId: growthGovernorResult?.cycleId,
          autonomousGrowthSourceChanged: growthGovernorResult?.sourceChanged,
          autonomousGrowthGapCount: growthGovernorResult?.gapsObserved,
        },
      };

      this.executionLogs.unshift(logRecord);
      this.lastRunTimestamp = Date.now();
      this.nextScheduledRunTimestamp = Date.now() + this.intervalMinutes * 60 * 1000;
      this.saveState();

      // 安全な自己改善司令塔を1サイクルだけ進める。
      // ここでは自己コード生成を直接許可せず、Knowledge Gap / Stable Case /
      // Regression候補など、既存の安全境界を持つ改善経路だけを選択する。
      try {
        const queuedRequest = selfImprovementIngressService.submit({
          trigger: `background:${triggerSource}`,
          source: 'EXECUTION',
          runType: 'EXECUTION_FAILURE',
          sourceId: logRecord.id,
          priority: 60,
          payload: { triggerSource, backgroundExecutionId: logRecord.id },
        });
        weaknessFound.push(`[自己改善Queue受付] ${queuedRequest.id}`);
      } catch (improvementErr: unknown) {
        const message = improvementErr instanceof Error ? improvementErr.message : String(improvementErr);
        systemLogger.warn('SELF_IMPROVEMENT', `自己改善Queue受付をスキップしました: ${message}`);
      }

      logRecord.details.weaknessFound = weaknessFound;
      systemLogger.info('SELF_IMPROVEMENT', `✓ WorkManager 自律処理完了 (${durationMs}ms)`);
      return logRecord;
    } catch (err: any) {
      const durationMs = Date.now() - startTime;
      const isAborted = abortSignal.aborted;
      const failedRecord: BackgroundTaskExecutionLog = {
        id: logId,
        timestamp: Date.now(),
        taskType: 'autonomous_cycle',
        status: isAborted ? 'aborted_constraint' : 'failed',
        durationMs,
        batteryLevel: this.batteryState.level,
        isCharging: this.batteryState.charging,
        isWifi: this.networkState.isWifi,
        summary: isAborted
          ? `安全中断: ${abortSignal.reason || 'ユーザーチャット操作割り込み検知'}`
          : `自律処理例外: ${err?.message || '不明なエラー'}`,
        details: {},
      };
      this.executionLogs.unshift(failedRecord);
      this.saveState();
      throw err;
    } finally {
      this.isExecutingNow = false;
      this.currentSleepState = 'idle';
      this.activeAbortController = null;
    }
  }

  /**
   * Android Kotlin WorkManager 用コード生成 (Section 23 準拠)
   */
  public generateAndroidWorkManagerCode(): string {
    return `// Android Kotlin WorkManager Implementation (MikiAI Autonomous Worker)
// app/src/main/java/com/mikiai/worker/MikiAutonomousWorker.kt

package com.mikiai.worker

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

class MikiAutonomousWorker(appContext: Context, workerParams: WorkerParameters) :
    CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        return try {
            // 浅い睡眠: 記憶統合 & 重複除去
            // 深い睡眠 (充電中・低温時): 弱点自己対話シミュレーション & A/Bテスト
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun schedulePeriodicWork(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiresCharging(${this.constraints.requiresCharging})
                .setRequiresDeviceIdle(${this.constraints.requiresDeviceIdle})
                .setRequiredNetworkType(${
                  this.constraints.requiresUnmeteredWifi
                    ? 'NetworkType.UNMETERED'
                    : 'NetworkType.CONNECTED'
                })
                .setRequiresBatteryNotLow(${this.constraints.batteryNotLow})
                .build()

            val workRequest = PeriodicWorkRequestBuilder<MikiAutonomousWorker>(
                ${this.intervalMinutes}, TimeUnit.MINUTES,
                30, TimeUnit.MINUTES // Flex interval
            )
            .setConstraints(constraints)
            .addTag("MikiAutonomousWork")
            .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                "MikiAutonomousSelfImprovement",
                ExistingPeriodicWorkPolicy.KEEP,
                workRequest
            )
        }
    }
}`;
  }

  public getStatus(): WorkManagerStatus {
    const conditions = this.getExecutionConditions();
    const shallowReasons = getShallowSleepUnmetReasons(conditions);
    const deepReasons = getDeepSleepUnmetReasons(conditions);

    return {
      isRegistered: this.isRegistered,
      lastRunTimestamp: this.lastRunTimestamp,
      nextScheduledRunTimestamp: this.nextScheduledRunTimestamp,
      intervalMinutes: this.intervalMinutes,
      constraints: { ...this.constraints },
      currentBatteryState: { ...this.batteryState },
      currentNetworkState: { ...this.networkState },
      isIdle: !conditions.isUserActive,
      isExecutingNow: this.isExecutingNow,
      currentSleepState: this.currentSleepState,
      currentConditions: conditions,
      unmetReasons: {
        shallow: shallowReasons,
        deep: deepReasons,
      },
    };
  }

  public updateConstraints(newConstraints: Partial<WorkManagerConstraints>): void {
    this.constraints = { ...this.constraints, ...newConstraints };
    this.saveState();
    this.syncNativeWorkManagerSchedule();
  }

  public updateInterval(minutes: number): void {
    this.intervalMinutes = Math.max(15, minutes);
    this.scheduleNextRun();
    this.saveState();
    this.syncNativeWorkManagerSchedule();
  }

  public toggleRegistered(registered: boolean): void {
    this.isRegistered = registered;
    this.saveState();
    this.syncNativeWorkManagerSchedule();
    if (registered) {
      nativeBackgroundService.start().catch(() => {});
    } else {
      nativeBackgroundService.stop().catch(() => {});
    }
  }

  public setMockBattery(charging: boolean, level: number): void {
    this.batteryState.charging = charging;
    // level: 0〜1 または 0〜100 の両方に対応
    this.batteryState.level = level <= 1 ? Math.round(level * 100) : Math.round(level);
    systemLogger.info(
      'SELF_IMPROVEMENT',
      `[Mock] バッテリー状態変更 -> ${charging ? '充電中' : '放電中'}, 残量: ${this.batteryState.level}%`
    );
  }

  /**
   * 実測バッテリー温度(摂氏)からサーマルステートを算出して反映 (提案B)
   */
  public updateFromTemperatureCelsius(celsius: number): void {
    let state: 'normal' | 'warm' | 'hot' | 'critical' = 'normal';
    if (celsius >= 46) {
      state = 'critical';
    } else if (celsius >= 42) {
      state = 'hot';
    } else if (celsius >= 38) {
      state = 'warm';
    } else {
      state = 'normal';
    }
    systemLogger.info(
      'SELF_IMPROVEMENT',
      `[Android Bridge] バッテリー温度実測 ${celsius.toFixed(1)}℃ -> サーマルステート: ${state}`
    );
    this.setThermalState(state);
  }

  public setThermalState(state: 'normal' | 'warm' | 'hot' | 'critical'): void {
    this.thermalState = state;
    systemLogger.info('SELF_IMPROVEMENT', `[Mock/API] サーマルステート変更 -> ${state}`);
    if ((state === 'hot' || state === 'critical') && this.currentSleepState === 'deep') {
      this.abortDeepSleepExecution(`端末発熱 (${state}) が検知されたため深い睡眠処理を安全に中断しました`);
    }
  }

  public setMockWifi(isWifi: boolean): void {
    this.networkState.isWifi = isWifi;
  }

  public getLogs(): BackgroundTaskExecutionLog[] {
    return [...this.executionLogs];
  }

  public clearLogs(): void {
    this.executionLogs = [];
    storageService.removeItem(WORK_MANAGER_LOGS_KEY);
  }
}

export const backgroundWorkerService = new BackgroundWorkerService();
