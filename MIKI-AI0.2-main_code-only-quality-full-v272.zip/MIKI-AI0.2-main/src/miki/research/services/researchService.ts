import { unifiedWebResearchService } from './unifiedWebResearchService';
import { knowledgeGapService, KnowledgeGap } from '../../unknown/services/knowledgeGapService';
import { evidenceService, EvidenceRecord } from '../../memory/services/evidenceService';
import { researchStrategyService, ResearchRoute } from './researchStrategyService';
import { cognitiveEvidenceIntegrationService } from '../../selfAwareness/services/cognitiveEvidenceIntegrationService';
import { mikiUnifiedLearningContinuumService } from '../../learning/services/mikiUnifiedLearningContinuumService';
import { webTermLearningService } from './webTermLearningService';
import { researchQueryPlanningService } from './researchQueryPlanningService';
import { researchQueryOutcomeLearningService } from './researchQueryOutcomeLearningService';
import { webResearchPolicyService, WebResearchProgress } from './webResearchPolicyService';
import { claimDatabaseService } from '../../memory/services/claimDatabaseService';
import {
  WebMaterialPatternExtractor,
  type WebImplementationMaterial,
} from './webMaterialPatternExtractor';

export type { ResearchRoute };

export type ResearchOutcomeState =
  | 'EVIDENCE_FOUND'
  | 'NO_RESULT'
  | 'INSUFFICIENT_SEARCH'
  | 'INSUFFICIENT_VERIFICATION'
  | 'SOURCE_UNAVAILABLE'
  | 'NOT_FOUND_AFTER_COVERAGE'
  | 'CONFIRMED_ABSENCE';

export interface ResearchSearchResult { title:string; snippet:string; source:string; url?:string; publishedDate?:string; sourceId?:string; independenceClusterId?:string; claimText?:string; }

export interface ResearchResult {
  gapId: string;
  results: ResearchSearchResult[];
  route: ResearchRoute;
  performed: boolean;
  evidence: EvidenceRecord[];
  claimIds: string[];
  resolved: boolean;
  reason: string;
  outcome: ResearchOutcomeState;
  summary?: string;
  verification?: VerificationResult[];
  roundsCompleted?: number;
  continuationAvailable?: boolean;
  continuationReason?: string;
  nextQuery?: string;
  researchQuery?: string;
  continuationRound?: number;
  routes?: ResearchRoute[];
  localClaimIds?: string[];
}

/**
 * Research orchestration and Evidence acquisition.
 *
 * Invariants:
 * - Search output is Evidence first.
 * - Synthetic/offline fallback is rejected by EvidenceService.
 * - Evidence-derived Claims remain UNVERIFIED.
 * - Search alone never resolves a Knowledge Gap.
 * - Only a later explicit verifier may promote Claims or resolve the Gap.
 */
function assessResearchSourceRole(query: { intentType?: string; sourceTierTarget?: string; siteOrDomainConstraints?: string[] }, page: { url: string }): "PRIMARY"|"OFFICIAL"|"SECONDARY"|"COUNTEREVIDENCE"|"UNCLASSIFIED" {
  if (query.intentType === "COUNTEREVIDENCE") return "COUNTEREVIDENCE";
  const host = (() => { try { return new URL(page.url).hostname.toLowerCase().replace(/^www\./, ""); } catch { return ""; } })();
  const constraints = (query.siteOrDomainConstraints || []).map(v => v.toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").split("/")[0]).filter(Boolean);
  if (host && constraints.some(domain => host === domain || host.endsWith("." + domain))) return "OFFICIAL";
  return "UNCLASSIFIED";
}

export class ResearchService {
  private static instance: ResearchService;

  private constructor() {}

  public static getInstance(): ResearchService {
    if (!ResearchService.instance) {
      ResearchService.instance = new ResearchService();
    }
    return ResearchService.instance;
  }

  public async executeSearch(query: string, options?: { maxResults?: number; sourceRequestId?: string }): Promise<ResearchResult> {
    const text = query.trim();
    if (!text) throw new Error("RESEARCH_QUERY_REQUIRED");
    const gap = knowledgeGapService.detect({ query: text, type: "INSUFFICIENT_EVIDENCE", reason: "通常のWeb知識探索要求をResearchServiceへ統合", priority: 50, sourceRequestId: options?.sourceRequestId });
    return this.researchGap(gap, { forceRoute: "WEB_SEARCH", query: text, maxPagesPerPass: Math.max(1, Math.min(3, options?.maxResults || 2)) });
  }

  /**
   * 自律コード改善が必要とする実装材料をResearch正規経路から収集する。
   *
   * Candidate/Unknown側からUnifiedWebResearchServiceを直接呼ばない。
   * Search -> page read -> implementation material extractionをResearch側へ集約し、
   * Candidate側は結果だけを利用する。
   */
  public async collectImplementationMaterials(
    query: string,
    options?: { maxResults?: number; maxPages?: number },
  ): Promise<WebImplementationMaterial[]> {
    const text = query.trim();
    if (!text) return [];

    const maxResults = Math.max(1, Math.min(6, options?.maxResults ?? 4));
    const maxPages = Math.max(1, Math.min(4, options?.maxPages ?? 3));

    const raw = await unifiedWebResearchService.executePlannedSearch(text);
    const results = this.normalizeSearchResults(raw).slice(0, maxResults);
    if (results.length === 0) return [];

    const pages = await unifiedWebResearchService.readSearchResultPages(
      text,
      results,
      { maxPages },
    );

    const materials: WebImplementationMaterial[] = [];

    for (const page of pages) {
      if (!page.success || !page.text.trim()) continue;

      const source = String(page.result.source || '').toLowerCase();
      const provider =
        source.includes('searxng') ? 'searxng' :
        source.includes('wikipedia') ? 'wikipedia' :
        source.includes('duckduckgo') ? 'duckduckgo' :
        'headless_webview';

      materials.push(
        ...WebMaterialPatternExtractor.extractImplementationMaterialsFromWebText({
          text: page.text,
          sourceQuery: text,
          sourceUrl: page.url,
          provider,
          fetchMethod: 'headless_webview',
        }),
      );
    }

    return materials;
  }

  public async researchGap(gap: KnowledgeGap, options?: {
    forceRoute?: ResearchRoute;
    requireFresh?: boolean;
    maxAgeDays?: number;
    maxPasses?: number;
    adaptive?: boolean;
    maxPagesPerPass?: number;
    query?: string;
    continuationRound?: number;
  }): Promise<ResearchResult> {
    const evidence: EvidenceRecord[] = [];
    const claimIds: string[] = [];
    const requiredResearchClaimIds: string[] = [];
    const learnedTermComponentIds: string[] = [];
    const searchResults: ResearchSearchResult[] = [];

    knowledgeGapService.buildResolutionPlan(gap);
    knowledgeGapService.advanceResolutionPlan(gap.id, 'COLLECT_EVIDENCE', 'RESEARCH');
    knowledgeGapService.markResearching(gap.id);
    const startedAt = Date.now();
    const baseQuery = typeof options?.query === 'string' && options.query.trim().length > 0
      ? options.query.trim()
      : gap.query;
    const continuationRound = Number.isFinite(options?.continuationRound)
      ? Math.max(0, Math.floor(options!.continuationRound!))
      : 0;
    /*
     * P0: 固定3回を最終仕様にしない。
     * 1回の呼び出しには安全な実行上限を置くが、adaptive=trueなら
     * COREが同じKnowledge Gapを次のcycleで再投入できる。
     * これにより「無限HTTP」ではなく、状態を持った論理的に無制限な探索になる。
     */
    const adaptive = options?.adaptive !== false;
    const requestedPasses = Number.isFinite(options?.maxPasses)
      ? Math.max(1, Math.floor(options!.maxPasses!))
      : 2;
    const queryPlan = researchQueryPlanningService.buildPlan(baseQuery, gap.researchClaimIds || []);
    const invocationPassLimit = Math.min(
      queryPlan.policy.maxTotalSearchRequests,
      queryPlan.policy.maxQueriesPerPlan,
      adaptive ? Math.max(requestedPasses, queryPlan.queries.length) : Math.min(3, requestedPasses),
    );
    const maxPagesPerPass = Math.max(1, Math.min(3, options?.maxPagesPerPass ?? 2));
    const strategy = options?.forceRoute
      ? { route: options.forceRoute, reason: '呼び出し元が明示的にこの研究経路を要求しました。', alternatives: [] as ResearchRoute[] }
      : researchStrategyService.chooseRoute(gap.type, gap.query);

    try {
      /*
       * LOCAL is a real Research strand.
       *
       * Important: LOCAL does not replace WEB.
       * Existing claims are collected as local evidence first, then WEB
       * research continues so freshness / official source / counterevidence
       * can be compared against the local knowledge.
       */
      const localClaimIds: string[] = [];
      const localMatch = claimDatabaseService.findBestMatchingClaim(baseQuery);

      if (localMatch.hasMatch) {
        const localClaims = [
          ...(localMatch.supportingClaims || []),
          ...(localMatch.contradictingClaims || []),
        ];

        const seenLocalClaims = new Set<string>();

        for (const claim of localClaims) {
          if (seenLocalClaims.has(claim.claim_id)) continue;
          seenLocalClaims.add(claim.claim_id);

          const localEvidence = evidenceService.recordLocalClaimEvidence({
            title: `LOCAL Claim [${claim.status}]`,
            statement: claim.statement,
            sourceId: claim.claim_id,
            independenceClusterId: claim.independence_cluster_id,
            metadata: {
              environment: 'MIKI-AI0.2 local claim database',
              observed_at: Date.now(),
              result_summary: `LOCAL Claim DBからResearch queryへの既存知識照合: ${localMatch.confidence}`,
            },
          });

          evidence.push(localEvidence);

          if (!localClaimIds.includes(claim.claim_id)) {
            localClaimIds.push(claim.claim_id);
          }

          if (evidenceService.attachEvidenceToClaim(
            localEvidence.evidence_id,
            claim.claim_id,
          )) {
            if (!claimIds.includes(claim.claim_id)) {
              claimIds.push(claim.claim_id);
            }
          }
        }

        if (localClaims.length > 0) {
          researchStrategyService.recordOutcome(
            gap.type,
            'LOCAL_CLAIM',
            true,
            Date.now() - startedAt,
          );
        }
      } else {
        researchStrategyService.recordOutcome(
          gap.type,
          'LOCAL_CLAIM',
          false,
          Date.now() - startedAt,
        );
      }

      // LOCALだけで終了しない。
      // LOCAL knowledgeを現在のWeb evidenceで補強・更新・反証する。
      // 自動検索判定がfalseでもKnowledge Gapとして明示的に登録された調査は、
      // StrategyがWEB_SEARCHを選択した場合に限り実行する。
      const need = unifiedWebResearchService.detectNeedForSearch(gap.query);
      if (!need.needsSearch && strategy.route !== 'WEB_SEARCH') {
        const hasLocalEvidence = evidence.some(
          item => item.kind === 'LOCAL_CLAIM' && item.status !== 'REJECTED'
        );

        return {
          gapId: gap.id,
          results: searchResults,
          route: 'LOCAL_CLAIM',
          routes: ['LOCAL_CLAIM'],
          localClaimIds,
          performed: hasLocalEvidence,
          evidence,
          claimIds,
          resolved: false,
          reason: hasLocalEvidence
            ? `LOCAL Claimから既存知識を取得しました。Web検索対象としての必要性は低いため、LOCAL結果をCOREへ返します。`
            : `LOCAL Claimにも該当知識がなく、今回のResearchでは外部検索を実行しませんでした。`,
          outcome: hasLocalEvidence ? 'EVIDENCE_FOUND' : 'SOURCE_UNAVAILABLE',
        };
      }

      let summary: string | undefined;
      let verification: unknown[] = [];
      let resolved = false;
      let continuationAvailable = false;
      let continuationReason = '';
      let nextQuery = gap.query;
      let roundsCompleted = 0;
      let previousEvidenceFingerprint = '';
      let previousEvidenceIds: string[] = [];
      let previousIndependentClusters: string[] = [];

      let recommendedRevisionQuery: string | undefined;
      let latestWebResearchProgress: WebResearchProgress | undefined;

      const buildAdaptiveQuery = (round: number, results: VerificationResult[]): string => {
        if (round === 0) return baseQuery;
        if (recommendedRevisionQuery) return recommendedRevisionQuery;
        const reasons = results.flatMap(result => Array.isArray(result.reasons) ? result.reasons : [])
          .map(String)
          .filter(Boolean);
        const focus = reasons.length > 0
          ? [...new Set(reasons)].slice(0, 4).join(' / ')
          : 'independent evidence / official documentation / counterevidence / compatibility';
        return `${baseQuery} / adaptive research round ${continuationRound + round + 1} / ${focus}`;
      };

      for (let pass = 0; pass < invocationPassLimit; pass++) {
        roundsCompleted = pass + 1;
        const plannedQuery = queryPlan.status === 'READY'
          ? queryPlan.queries[pass]?.queryText
          : undefined;
        const passQuery = plannedQuery || buildAdaptiveQuery(pass, verification);
        nextQuery = passQuery;
        const queryStartedAt = Date.now();
        const raw = await unifiedWebResearchService.executePlannedSearch(passQuery, {
          bypassCache: pass > 0,
        });
        const results = this.normalizeSearchResults(raw);
        searchResults.push(...results);
        if (typeof (raw as any)?.summary === 'string') summary = (raw as any).summary;

        // Search is only the discovery step. Read the selected result pages before
        // building the final evidence/claim set, so SearXNG -> page content -> Evidence
        // is one Research pipeline rather than two disconnected services.
        const readResults = await unifiedWebResearchService.readSearchResultPages(passQuery, results, {
          maxPages: maxPagesPerPass,
        });

        for (const page of readResults) {
          if (!page.success || !page.text.trim()) continue;
          const itemSource = String(page.result.source || '').toLowerCase();
          const sourceProvider = itemSource.includes('searxng')
            ? 'searxng'
            : itemSource.includes('wikipedia')
              ? 'wikipedia'
              : itemSource.includes('duckduckgo')
                ? 'duckduckgo'
                : 'headless_webview';
          const content = page.text.trim().slice(0, 12000);
          const pageEvidence = evidenceService.recordWebEvidence({
            title: `${page.result.title} [本文読取]`,
            snippet: content,
            source: sourceProvider,
            url: page.url,
            publishedDate: page.result.publishedDate,
            sourceId: page.result.sourceId,
            independenceClusterId: page.result.independenceClusterId,
            metadata: {
              fetch_method: 'headless_webview',
              observed_at: Date.now(),
              environment: 'MIKI-AI0.2 research page reader',
              result_summary: `検索結果URLを実際に読み取り、本文${page.text.length}文字を取得`,
              research_query_id: queryPlan.status === "READY" ? queryPlan.queries[pass]?.queryId : undefined,
              research_query_plan_id: queryPlan.status === "READY" ? queryPlan.planId : undefined,
              research_source_tier_target: queryPlan.status === "READY" ? queryPlan.queries[pass]?.sourceTierTarget : undefined,
              research_intent_type: queryPlan.status === "READY" ? queryPlan.queries[pass]?.intentType : undefined,
              research_source_role_target: queryPlan.status === "READY" ? ({ COUNTEREVIDENCE: "COUNTEREVIDENCE", PRIMARY_SOURCE: "PRIMARY", OFFICIAL_SPECIFICATION: "OFFICIAL" } as Record<string,string>)[queryPlan.queries[pass]?.intentType || ""] || "UNCLASSIFIED" : "UNCLASSIFIED",
              research_source_role: queryPlan.status === "READY" ? assessResearchSourceRole(queryPlan.queries[pass], { url: page.url }) : "UNCLASSIFIED",
              research_source_provider: String(page.result.source || ""),
              research_source_engine: String((page.result as any).engine || ""),
              research_source_author: String((page.result as any).author || ""),
              research_source_category: String((page.result as any).category || ""),
              research_source_metadata: String((page.result as any).metadata || ""),
            },
          });
          evidence.push(pageEvidence);

          if (pageEvidence.status !== 'REJECTED') {
            const termLearning = webTermLearningService.learnPage({
              text: content,
              url: page.url,
              evidenceId: pageEvidence.evidence_id,
              sourceTitle: page.result.title,
            });
            for (const componentId of termLearning.componentIds) {
              if (!learnedTermComponentIds.includes(componentId)) {
                learnedTermComponentIds.push(componentId);
              }
            }
          }

          if (pageEvidence.status === 'REJECTED') continue;
          // The page itself is evidence; keep the claim conservative by using the
          // original search snippet when available rather than treating the whole page as one fact.
          const pageClaimStatement = (page.result.claimText || page.result.snippet || content.slice(0, 1000)).trim();
          const normalizedPageStatement = this.normalizeClaimStatement(pageClaimStatement);
          if (!pageClaimStatement) continue;
          let pageClaimId = evidenceService.registerUnverifiedClaim(pageEvidence.evidence_id, pageClaimStatement);
          if (pageClaimId && !claimIds.includes(pageClaimId)) claimIds.push(pageClaimId);
          if (!pageClaimId && normalizedPageStatement) {
            // Claim linkage is intentionally deferred to the normal search-evidence pass below.
          }
        }

        let canonicalClaimId: string | undefined;
        let canonicalStatement = '';

        for (const result of results) {
        const record = evidenceService.recordWebEvidence({
          title: result.title,
          snippet: result.snippet,
          source: result.source,
          url: result.url,
          publishedDate: result.publishedDate,
          sourceId: result.sourceId,
          independenceClusterId: result.independenceClusterId,
        });

        evidence.push(record);

        // Rejected synthetic/offline results can never become Claims.
        if (record.status === 'REJECTED') continue;

        const statement = (result.claimText || result.snippet).trim();
        const normalizedStatement = this.normalizeClaimStatement(statement);

        // Conservative grouping: only evidence with the same normalized statement
        // is attached to one Claim. Different wording creates a separate Claim,
        // so the verifier never assumes semantic agreement from mere co-occurrence.
        let claimId: string | undefined;
        if (canonicalClaimId && normalizedStatement === canonicalStatement) {
          if (evidenceService.attachEvidenceToClaim(record.evidence_id, canonicalClaimId)) {
            claimId = canonicalClaimId;
          }
        } else {
          claimId = evidenceService.registerUnverifiedClaim(record.evidence_id, statement);
          if (claimId && !canonicalClaimId) {
            canonicalClaimId = claimId;
            canonicalStatement = normalizedStatement;
          }
        }

        if (claimId && !claimIds.includes(claimId)) claimIds.push(claimId);

      }

        // ResearchはEvidence/Claimの収集までを担当し、VerificationはCORE経由で実行する。
        knowledgeGapService.advanceResolutionPlan(gap.id, 'VERIFY', 'RESEARCH');
        knowledgeGapService.attachResearchClaims(gap.id, claimIds);
        knowledgeGapService.attachResearchRequiredClaims(gap.id, requiredResearchClaimIds);
        verification = [];
        resolved = false;

        if (queryPlan.status === "READY" && queryPlan.queries[pass]) { const passEvidenceIds = [...new Set(evidence.filter(item => item.status !== "REJECTED").map(item => item.evidence_id))]; const passClusters = new Set(evidence.filter(item => item.status !== "REJECTED" && item.independence_cluster_id).map(item => item.independence_cluster_id)); researchQueryOutcomeLearningService.record({ queryPlanId: queryPlan.planId, queryId: queryPlan.queries[pass].queryId, queryText: queryPlan.queries[pass].queryText, status: passEvidenceIds.length ? "EVIDENCE_GAINED" : results.length ? "LOW_QUALITY_RESULTS" : "NO_RESULTS", candidateUrlCount: results.filter(result => !!result.url).length, renderedPageCount: readResults.filter(page => page.success && !!page.text.trim()).length, admissibleIndependentSourceCount: passClusters.size, primarySourceCount: passEvidenceIds.filter(id => { const item = evidence.find(e => e.evidence_id === id); return item?.status !== "REJECTED" && (item?.metadata?.research_source_role === "PRIMARY" || item?.metadata?.research_source_role === "OFFICIAL"); }).length, sourceTierTarget: queryPlan.queries[pass].sourceTierTarget, counterevidenceChecked: queryPlan.queries[pass].intentType === "COUNTEREVIDENCE", evidenceIds: passEvidenceIds, failureReasons: verification.filter(result => result.outcome === "UNRESOLVED").flatMap(result => result.reasons), environmentApplicability: "CURRENT_ENVIRONMENT", executionTimeMs: Date.now() - queryStartedAt, attempt: pass + 1 }); }

        if (queryPlan.status === "READY" && queryPlan.queries[pass]) {
          const revision = researchQueryOutcomeLearningService.recommendRevision(queryPlan.planId, queryPlan.queries[pass].queryId);
          if (revision.shouldRevise && revision.revisedQuery) { recommendedRevisionQuery = revision.revisedQuery; nextQuery = revision.revisedQuery; }
        }

        const webResearchPolicy = webResearchPolicyService.get();
        const completedIntentTypes = queryPlan.status === "READY"
          ? queryPlan.queries.slice(0, pass + 1).filter(query => evidence.some(item => item.status !== "REJECTED" && item.metadata?.research_intent_type === query.intentType && !!item.url)).map(query => query.intentType)
          : [];
        const requiredIntentTypes = queryPlan.status === "READY"
          ? queryPlan.queries.filter(query => query.intentType === "BASELINE" || query.intentType === "OFFICIAL_SPECIFICATION" || query.intentType === "CURRENT_ENVIRONMENT" || query.intentType === "COUNTEREVIDENCE" || query.intentType === "PRIMARY_SOURCE").map(query => query.intentType)
          : [];
        const webResearchProgress: WebResearchProgress = {
          acceptedIndependentSourceCount: new Set(evidence.filter(item => item.status !== "REJECTED" && item.independence_cluster_id).map(item => item.independence_cluster_id)).size,
          candidateUrlsChecked: results.filter(result => !!result.url).length,
          renderedPages: readResults.filter(page => page.success && !!page.text.trim()).length,
          supportingSourceCount: verification.filter(result => result.outcome === "SUPPORTED" || result.outcome === "DEVICE_VERIFIED").length,
          counterEvidenceSourceCount: evidence.filter(item => item.status !== "REJECTED" && item.metadata?.research_source_role === "COUNTEREVIDENCE").length,
          primarySourceSatisfied: evidence.some(item => item.status !== "REJECTED" && (item.metadata?.research_source_role === "PRIMARY" || (item.metadata?.research_source_role === "OFFICIAL" && item.metadata?.research_source_tier_target === "PRIMARY_OR_OFFICIAL"))),
          counterEvidenceSearchCompleted: queryPlan.status === "READY" && queryPlan.queries.slice(0, pass + 1).some(query => query.intentType === "COUNTEREVIDENCE" && evidence.some(item => item.status !== "REJECTED" && !!item.url)),
          excludedDuplicateCount: 0,
          rejectedQualityCount: evidence.filter(item => item.status === "REJECTED").length,
          conflictingEvidence: verification.some(result => result.outcome === "CONTRADICTED"),
          requiredIntentTypes: [...new Set(requiredIntentTypes)],
          completedIntentTypes: [...new Set(completedIntentTypes)],
          environmentApplicabilitySatisfied: queryPlan.status !== "READY" || !requiredIntentTypes.includes("CURRENT_ENVIRONMENT") || completedIntentTypes.includes("CURRENT_ENVIRONMENT"),
        };
        latestWebResearchProgress = webResearchProgress;

        const evidenceFingerprint = [...new Set(evidence.map(item => `${item.source_id}|${item.independence_cluster_id}|${item.url}`))]
          .sort()
          .join('||');
        const currentEvidenceIds = [...new Set(
          evidence.filter(item => item.status !== 'REJECTED').map(item => item.evidence_id)
        )];
        const currentIndependentClusters = [...new Set(
          evidence
            .filter(item => item.status !== 'REJECTED' && item.independence_cluster_id)
            .map(item => item.independence_cluster_id as string)
        )];
        const meaningfulness = researchStrategyService.assessMeaningfulness({
          previousEvidenceIds,
          currentEvidenceIds,
          previousIndependentClusters,
          currentIndependentClusters,
          previousCoverage: previousIndependentClusters,
          currentCoverage: currentIndependentClusters,
        });
        const noNewEvidence = evidenceFingerprint !== '' && evidenceFingerprint === previousEvidenceFingerprint;
        previousEvidenceFingerprint = evidenceFingerprint;
        previousEvidenceIds = currentEvidenceIds;
        previousIndependentClusters = currentIndependentClusters;

        const webPolicySatisfied = webResearchPolicy.stopWhenTargetReached && webResearchPolicyService.isSatisfied(webResearchProgress, webResearchPolicy);
        if (webPolicySatisfied && !resolved) {
          continuationAvailable = false;
          continuationReason = "INSUFFICIENT_VERIFICATION";
          break;
        }

        if (adaptive && (noNewEvidence || (!meaningfulness.meaningful && pass > 0))) {
          continuationAvailable = false;
          continuationReason = noNewEvidence ? 'NO_NEW_EVIDENCE' : 'LOW_INFORMATION_GAIN';
          knowledgeGapService.advanceResolutionPlan(gap.id, 'IDENTIFY', 'CLARIFY');
          break;
        }

        continuationAvailable = adaptive && pass + 1 >= invocationPassLimit;
        continuationReason = continuationAvailable
          ? 'NEXT_CORE_CYCLE_REQUIRED'
          : 'INSUFFICIENT_VERIFICATION';

        if (!adaptive) break;
      }

      mikiUnifiedLearningContinuumService.observe({
        domain: 'research',
        key: `knowledge-gap:${gap.id}`,
        action: 'adaptive_research_round',
        input: baseQuery,
        outcome: resolved ? 'SUCCESS' : 'FAILURE',
        verified: resolved,
        concepts: [gap.type, continuationReason || 'INSUFFICIENT_VERIFICATION'],
        lesson: resolved
          ? 'Research evidence was independently verified and promoted.'
          : continuationAvailable
            ? 'Research requires another CORE cycle with a new evidence query.'
            : continuationReason || 'Research stopped without sufficient verification.'
      });

      if (searchResults.length > 0 || summary) {
        unifiedWebResearchService.learnFromSearch(
          baseQuery,
          searchResults,
          summary,
          {
            triggerType: 'working_agenda',
            sourceRef: `research_gap:${gap.id}`,
            evidenceIds: [...new Set(evidence.filter(item => item.status !== 'REJECTED').map(item => item.evidence_id))],
            claimIds: [...new Set(claimIds)],
            researchGapId: gap.id,
            verificationStatus: resolved ? 'VERIFIED' : 'UNVERIFIED',
          }
        );
      }
      const observedEvidenceCount = evidence.filter(item => item.status !== 'REJECTED').length;
      const hasAnyResults = observedEvidenceCount > 0 || claimIds.length > 0;
      const coverageSatisfied = latestWebResearchProgress
        ? webResearchPolicyService.isSatisfied(latestWebResearchProgress, webResearchPolicyService.get())
        : false;
      const outcome: ResearchOutcomeState = resolved
        ? 'EVIDENCE_FOUND'
        : continuationAvailable
          ? 'INSUFFICIENT_SEARCH'
          : continuationReason === 'INSUFFICIENT_VERIFICATION'
            ? 'INSUFFICIENT_VERIFICATION'
            : continuationReason === 'NO_NEW_EVIDENCE' || continuationReason === 'LOW_INFORMATION_GAIN'
            ? 'INSUFFICIENT_SEARCH'
            : hasAnyResults
              ? (coverageSatisfied ? 'NOT_FOUND_AFTER_COVERAGE' : 'INSUFFICIENT_SEARCH')
              : (roundsCompleted > 0 ? 'NO_RESULT' : 'SOURCE_UNAVAILABLE');

      researchStrategyService.recordOutcome(gap.type, 'WEB_SEARCH', resolved, Date.now() - startedAt);
      return {
        gapId: gap.id,
        route: 'WEB_SEARCH',
        routes: ['LOCAL_CLAIM', 'WEB_SEARCH'],
        localClaimIds,
        performed: evidence.some((e) => e.status !== 'REJECTED'),
        evidence,
        claimIds,
        resolved,
        outcome,
        verification,
        summary,
        roundsCompleted,
        continuationAvailable,
        continuationReason,
        nextQuery,
        researchQuery: baseQuery,
        continuationRound,
        reason: resolved
          ? 'Web調査で得たEvidenceを独立性・矛盾条件で検証し、少なくとも1件のClaimをSUPPORTED/DEVICE_VERIFIEDへ昇格しました。'
          : continuationAvailable
            ? `現在のResearch実行枠では未解決です。COREは次cycleで同じKnowledge Gapを再評価し、次の探索ラウンドを継続できます。`
            : `Researchを${roundsCompleted}ラウンド実行しましたが、独立検証条件を満たさないためKnowledge Gapは未解決です。`,
      };
    } catch (error) {
      mikiUnifiedLearningContinuumService.observe({
        domain: 'research',
        key: `knowledge-gap:${gap.id}`,
        action: 'adaptive_research_error',
        input: baseQuery,
        outcome: 'FAILURE',
        verified: false,
        concepts: [gap.type, 'RESEARCH_ERROR'],
        lesson: error instanceof Error ? error.message : 'unknown research error'
      });
      researchStrategyService.recordOutcome(gap.type, strategy.route, false, Date.now() - startedAt);
      knowledgeGapService.markBlocked(
        gap.id,
        error instanceof Error ? error.message : 'unknown research error'
      );

      return {
        gapId: gap.id,
        route: 'WEB_SEARCH',
        performed: false,
        evidence,
        claimIds,
        resolved: false,
        outcome: evidence.length > 0 ? 'INSUFFICIENT_SEARCH' : 'SOURCE_UNAVAILABLE',
        researchQuery: baseQuery,
        continuationRound,
        reason: '調査中にエラーが発生したため、Knowledge GapをBLOCKEDにしました。',
      };
    }
  }

  private normalizeClaimStatement(text: string): string {
    return text
      .toLowerCase()
      .replace(/[\s\u3000]+/g, ' ')
      .replace(/[「」『』“”"'、。！？!?]/g, '')
      .trim();
  }

  private normalizeSearchResults(raw: unknown): Array<{
    title: string;
    snippet: string;
    source: string;
    url?: string;
    publishedDate?: string;
    sourceId?: string;
    independenceClusterId?: string;
    claimText?: string;
  }> {
    // autonomousSearchService currently returns { results, summary, provider }.
    // Accepting an array too keeps this adapter tolerant of older callers.
    const items = Array.isArray(raw)
      ? raw
      : Array.isArray((raw as any)?.results)
        ? (raw as any).results
        : [];

    return items
      .map((item: any) => ({
        title: String(item?.title || item?.name || 'Untitled result'),
        snippet: String(item?.snippet || item?.description || item?.text || ''),
        source: String(item?.source || item?.domain || 'unknown'),
        url: typeof item?.url === 'string' ? item.url : undefined,
        publishedDate:
          typeof item?.publishedDate === 'string' ? item.publishedDate : undefined,
        sourceId: typeof item?.sourceId === 'string' ? item.sourceId : undefined,
        independenceClusterId:
          typeof item?.independenceClusterId === 'string'
            ? item.independenceClusterId
            : undefined,
        claimText: typeof item?.claimText === 'string' ? item.claimText : undefined,
      }))
      .filter((item: { snippet: string }) => item.snippet.trim().length > 0);
  }
}

export const researchService = ResearchService.getInstance();
