function rotateRight(value: number, shift: number): number {
  return (value >>> shift) | (value << (32 - shift));
}

function canonicalize(value: unknown): string {
  if (Array.isArray(value)) return `[${value.map(canonicalize).join(',')}]`;
  if (value && typeof value === 'object') {
    return `{${Object.entries(value as Record<string, unknown>)
      .filter(([, item]) => item !== undefined)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([key, item]) => `${JSON.stringify(key)}:${canonicalize(item)}`).join(',')}}`;
  }
  return JSON.stringify(value);
}

function utf8(text: string): number[] {
  return Array.from(new TextEncoder().encode(text));
}

export function sha256HexFromText(text: string): string {
  const constants = [
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2,
  ];
  const hash = [0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19];
  const bytes = utf8(text); const bitLength = bytes.length * 8;
  bytes.push(0x80); while ((bytes.length % 64) !== 56) bytes.push(0);
  const high = Math.floor(bitLength / 0x100000000); const low = bitLength >>> 0;
  for (let shift = 24; shift >= 0; shift -= 8) bytes.push((high >>> shift) & 0xff);
  for (let shift = 24; shift >= 0; shift -= 8) bytes.push((low >>> shift) & 0xff);
  for (let offset = 0; offset < bytes.length; offset += 64) {
    const words = new Array<number>(64).fill(0);
    for (let index = 0; index < 16; index += 1) words[index] = ((bytes[offset+index*4]<<24)|(bytes[offset+index*4+1]<<16)|(bytes[offset+index*4+2]<<8)|bytes[offset+index*4+3]) >>> 0;
    for (let index = 16; index < 64; index += 1) {
      const s0 = rotateRight(words[index-15],7)^rotateRight(words[index-15],18)^(words[index-15]>>>3);
      const s1 = rotateRight(words[index-2],17)^rotateRight(words[index-2],19)^(words[index-2]>>>10);
      words[index] = (words[index-16]+s0+words[index-7]+s1)>>>0;
    }
    let [a,b,c,d,e,f,g,h] = hash;
    for (let index = 0; index < 64; index += 1) {
      const s1=rotateRight(e,6)^rotateRight(e,11)^rotateRight(e,25); const choice=(e&f)^((~e)&g);
      const temp1=(h+s1+choice+constants[index]+words[index])>>>0; const s0=rotateRight(a,2)^rotateRight(a,13)^rotateRight(a,22);
      const majority=(a&b)^(a&c)^(b&c); const temp2=(s0+majority)>>>0;
      h=g;g=f;f=e;e=(d+temp1)>>>0;d=c;c=b;b=a;a=(temp1+temp2)>>>0;
    }
    const state=[a,b,c,d,e,f,g,h]; for(let index=0;index<8;index+=1)hash[index]=(hash[index]+state[index])>>>0;
  }
  return hash.map(value=>value.toString(16).padStart(8,'0')).join('');
}

export function canonicalSha256(value: unknown): string {
  return sha256HexFromText(canonicalize(value));
}

export const canonicalSha256Object = canonicalSha256;
