import type { CodeComponentDefinition, CodeKnowledgeDefinition } from './common';

/**
 * Browser / Web API
 * Knowledge と直接再利用可能な CODE Component を同一カテゴリで管理する。
 * platformCodeKnowledge.ts から分離した静的な登録元。
 */
export const browserWebApiCodeKnowledge: CodeKnowledgeDefinition[] = [
  {
      id: 'code.web-api.fetch',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'Fetch request',
      summary: 'Fetch requestをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['fetch', 'fetch'],
      inputs: ['input'],
      outputs: ['response'],
      appliesWhen: ['web-api', 'fetch'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'await fetch({url}, {options});',
        outputKinds: ['response'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.headers',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'HTTP Headers',
      summary: 'HTTP HeadersをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['Headers', 'headers'],
      inputs: ['input'],
      outputs: ['headers'],
      appliesWhen: ['web-api', 'headers'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new Headers({init});',
        outputKinds: ['headers'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.request',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'HTTP Request',
      summary: 'HTTP RequestをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['Request', 'request'],
      inputs: ['input'],
      outputs: ['request'],
      appliesWhen: ['web-api', 'request'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new Request({url}, {options});',
        outputKinds: ['request'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.response',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'HTTP Response',
      summary: 'HTTP ResponseをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['Response', 'response'],
      inputs: ['input'],
      outputs: ['response'],
      appliesWhen: ['web-api', 'response'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new Response({body}, {options});',
        outputKinds: ['response'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.form-data',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'FormData',
      summary: 'FormDataをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['FormData', 'form-data'],
      inputs: ['input'],
      outputs: ['FormData'],
      appliesWhen: ['web-api', 'form-data'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'const {form} = new FormData();',
        outputKinds: ['FormData'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.blob',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'Blob',
      summary: 'BlobをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['Blob', 'blob'],
      inputs: ['input'],
      outputs: ['Blob'],
      appliesWhen: ['web-api', 'blob'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new Blob({parts}, {options});',
        outputKinds: ['Blob'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.file',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'File',
      summary: 'FileをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['File', 'file'],
      inputs: ['input'],
      outputs: ['File'],
      appliesWhen: ['web-api', 'file'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new File({parts}, {name}, {options});',
        outputKinds: ['File'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.event-target',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'EventTarget',
      summary: 'EventTargetをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['EventTarget', 'event-target'],
      inputs: ['input'],
      outputs: ['listener'],
      appliesWhen: ['web-api', 'event-target'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: '{target}.addEventListener({event}, {handler});',
        outputKinds: ['listener'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.websocket',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'WebSocket',
      summary: 'WebSocketをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['WebSocket', 'websocket'],
      inputs: ['input'],
      outputs: ['WebSocket'],
      appliesWhen: ['web-api', 'websocket'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new WebSocket({url});',
        outputKinds: ['WebSocket'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.web-worker',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'Web Worker',
      summary: 'Web WorkerをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['Worker', 'web-worker'],
      inputs: ['input'],
      outputs: ['Worker'],
      appliesWhen: ['web-api', 'web-worker'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new Worker({url});',
        outputKinds: ['Worker'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.broadcast-channel',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'BroadcastChannel',
      summary: 'BroadcastChannelをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['BroadcastChannel', 'broadcast-channel'],
      inputs: ['input'],
      outputs: ['channel'],
      appliesWhen: ['web-api', 'broadcast-channel'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new BroadcastChannel({name});',
        outputKinds: ['channel'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.indexeddb',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'IndexedDB',
      summary: 'IndexedDBをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['IndexedDB', 'indexeddb'],
      inputs: ['input'],
      outputs: ['database request'],
      appliesWhen: ['web-api', 'indexeddb'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'indexedDB.open({name}, {version});',
        outputKinds: ['database request'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.storage',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'Web Storage',
      summary: 'Web StorageをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['Storage', 'storage'],
      inputs: ['input'],
      outputs: ['void'],
      appliesWhen: ['web-api', 'storage'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'localStorage.setItem({key}, {value});',
        outputKinds: ['void'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.clipboard',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'Clipboard',
      summary: 'ClipboardをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['Clipboard', 'clipboard'],
      inputs: ['input'],
      outputs: ['promise'],
      appliesWhen: ['web-api', 'clipboard'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'await navigator.clipboard.writeText({value});',
        outputKinds: ['promise'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.intersection-observer',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'IntersectionObserver',
      summary: 'IntersectionObserverをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['IntersectionObserver', 'intersection-observer'],
      inputs: ['input'],
      outputs: ['observer'],
      appliesWhen: ['web-api', 'intersection-observer'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new IntersectionObserver({callback}, {options});',
        outputKinds: ['observer'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
      id: 'code.web-api.resize-observer',
      componentType: 'CODE_PLATFORM_KNOWLEDGE',
      purpose: 'ResizeObserver',
      summary: 'ResizeObserverをMIKIの汎用コード構築語彙として扱う。',
      concepts: ['ResizeObserver', 'resize-observer'],
      inputs: ['input'],
      outputs: ['observer'],
      appliesWhen: ['web-api', 'resize-observer'],
      doesNotApplyWhen: [],
      sourceUrls: ['https://developer.mozilla.org/en-US/docs/Web/JavaScript'],
      sourceArtifactIds: ['platform-catalog-web-api'],
      constructionProfile: {
        kind: 'CALL',
        syntaxTemplate: 'new ResizeObserver({callback});',
        outputKinds: ['observer'],
        slots: [
          {name: 'input', inputKinds: ['expression'], required: true},
        ],
        constraints: ['Use the canonical API or architecture represented by this knowledge item.'],
        adaptationRules: ['Adapt arguments and surrounding syntax to the target project contract.'],
      },
    },
  {
    "id": "code.browser-web-api.fetch",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "HTTPリクエストをブラウザから実行する",
    "summary": "Fetch APIによるHTTP通信。",
    "concepts": [
      "fetch",
      "Request",
      "Response"
    ],
    "inputs": [
      "string-expression"
    ],
    "outputs": [
      "promise-expression"
    ],
    "appliesWhen": [
      "ブラウザからHTTP APIを呼び出す"
    ],
    "doesNotApplyWhen": [],
    "sourceUrls": [
      "https://developer.mozilla.org/"
    ],
    "sourceArtifactIds": [
      "generated-code.browser-web-api.fetch"
    ],
    "constructionProfile": {
      "kind": "ASYNC",
      "syntaxTemplate": "fetch({url})",
      "outputKinds": [
        "promise-expression"
      ],
      "slots": [
        {
          "name": "url",
          "inputKinds": [
            "string-expression"
          ],
          "required": true
        }
      ],
      "constraints": [],
      "adaptationRules": []
    }
  },
  {
    "id": "code.browser-web-api.blob",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "バイナリデータをBlobとして扱う",
    "summary": "Blobによるバイナリデータ表現。",
    "concepts": [
      "Blob",
      "binary",
      "MIME"
    ],
    "inputs": [
      "expression",
      "string-expression"
    ],
    "outputs": [
      "expression"
    ],
    "appliesWhen": [
      "ファイルやバイナリデータをBlob化する"
    ],
    "doesNotApplyWhen": [],
    "sourceUrls": [
      "https://developer.mozilla.org/"
    ],
    "sourceArtifactIds": [
      "generated-code.browser-web-api.blob"
    ],
    "constructionProfile": {
      "kind": "EXPRESSION",
      "syntaxTemplate": "new Blob([{parts}], {type})",
      "outputKinds": [
        "expression"
      ],
      "slots": [
        {
          "name": "parts",
          "inputKinds": [
            "expression"
          ],
          "required": true
        },
        {
          "name": "type",
          "inputKinds": [
            "string-expression"
          ],
          "required": false
        }
      ],
      "constraints": [],
      "adaptationRules": []
    }
  },
  {
    "id": "code.browser-web-api.local-storage",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "ブラウザの永続的なキー値ストレージを利用する",
    "summary": "localStorageによる簡易永続化。",
    "concepts": [
      "localStorage",
      "getItem",
      "setItem",
      "removeItem"
    ],
    "inputs": [
      "string-expression",
      "expression"
    ],
    "outputs": [
      "expression"
    ],
    "appliesWhen": [
      "ブラウザ内へ小規模データを保存する"
    ],
    "doesNotApplyWhen": [],
    "sourceUrls": [
      "https://developer.mozilla.org/"
    ],
    "sourceArtifactIds": [
      "generated-code.browser-web-api.local-storage"
    ],
    "constructionProfile": {
      "kind": "STATEMENT",
      "syntaxTemplate": "localStorage.setItem({key}, {value})",
      "outputKinds": [
        "expression"
      ],
      "slots": [
        {
          "name": "key",
          "inputKinds": [
            "string-expression"
          ],
          "required": true
        },
        {
          "name": "value",
          "inputKinds": [
            "expression"
          ],
          "required": true
        }
      ],
      "constraints": [],
      "adaptationRules": []
    }
  },
  {
    "id": "code.browser-web-api.url",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "URLを解析・構成する",
    "summary": "URL Web API。",
    "concepts": [
      "URL",
      "URLSearchParams"
    ],
    "inputs": [
      "string-expression"
    ],
    "outputs": [
      "expression"
    ],
    "appliesWhen": [
      "URLを安全に分解・構成する"
    ],
    "doesNotApplyWhen": [],
    "sourceUrls": [
      "https://developer.mozilla.org/"
    ],
    "sourceArtifactIds": [
      "construction-code.browser-web-api.url"
    ],
    "constructionProfile": {
      "kind": "EXPRESSION",
      "syntaxTemplate": "new URL({value})",
      "outputKinds": [
        "expression"
      ],
      "slots": [
        {
          "name": "value",
          "inputKinds": [
            "string-expression"
          ],
          "required": true
        }
      ],
      "constraints": [],
      "adaptationRules": []
    }
  },
  {
    "id": "code.browser-web-api.abort-controller",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "非同期ブラウザ処理を中断可能にする",
    "summary": "AbortControllerによるキャンセル。",
    "concepts": [
      "AbortController",
      "AbortSignal",
      "abort"
    ],
    "inputs": [],
    "outputs": [
      "expression"
    ],
    "appliesWhen": [
      "fetch等の処理へキャンセル制御を付与する"
    ],
    "doesNotApplyWhen": [],
    "sourceUrls": [
      "https://developer.mozilla.org/"
    ],
    "sourceArtifactIds": [
      "construction-code.browser-web-api.abort-controller"
    ],
    "constructionProfile": {
      "kind": "EXPRESSION",
      "syntaxTemplate": "new AbortController()",
      "outputKinds": [
        "expression"
      ],
      "slots": [],
      "constraints": [],
      "adaptationRules": []
    }
  },
  {
    "id": "code.browser-web-api.intersection-observer",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "要素の可視領域変化を監視する",
    "summary": "IntersectionObserverによる可視状態監視。",
    "concepts": [
      "IntersectionObserver",
      "visibility",
      "viewport"
    ],
    "inputs": [
      "function-expression"
    ],
    "outputs": [
      "expression"
    ],
    "appliesWhen": [
      "スクロール連動UIや遅延処理を構成する"
    ],
    "doesNotApplyWhen": [],
    "sourceUrls": [
      "https://developer.mozilla.org/"
    ],
    "sourceArtifactIds": [
      "construction-code.browser-web-api.intersection-observer"
    ],
    "constructionProfile": {
      "kind": "EXPRESSION",
      "syntaxTemplate": "new IntersectionObserver({callback})",
      "outputKinds": [
        "expression"
      ],
      "slots": [
        {
          "name": "callback",
          "inputKinds": [
            "function-expression"
          ],
          "required": true
        }
      ],
      "constraints": [],
      "adaptationRules": []
    }
  }

];

export const browserWebApiCodeComponents: CodeComponentDefinition[] = [
  {
    knowledgeId: "code.web-api.fetch",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "Fetch request",
    implementation: "await fetch({url}, {options});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['response'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.fetch",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.fetch\\ninputs=['input']\\noutputs=['response']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=await fetch({url}, {options});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.fetch\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.headers",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "HTTP Headers",
    implementation: "new Headers({init});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['headers'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.headers",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.headers\\ninputs=['input']\\noutputs=['headers']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new Headers({init});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.headers\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.request",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "HTTP Request",
    implementation: "new Request({url}, {options});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['request'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.request",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.request\\ninputs=['input']\\noutputs=['request']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new Request({url}, {options});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.request\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.response",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "HTTP Response",
    implementation: "new Response({body}, {options});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['response'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.response",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.response\\ninputs=['input']\\noutputs=['response']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new Response({body}, {options});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.response\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.form-data",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "FormData",
    implementation: "const {form} = new FormData();",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['FormData'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.form-data",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.form-data\\ninputs=['input']\\noutputs=['FormData']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=const {form} = new FormData();",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.form-data\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.blob",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "Blob",
    implementation: "new Blob({parts}, {options});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['Blob'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.blob",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.blob\\ninputs=['input']\\noutputs=['Blob']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new Blob({parts}, {options});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.blob\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.file",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "File",
    implementation: "new File({parts}, {name}, {options});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['File'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.file",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.file\\ninputs=['input']\\noutputs=['File']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new File({parts}, {name}, {options});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.file\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.event-target",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "EventTarget",
    implementation: "{target}.addEventListener({event}, {handler});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['listener'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.event-target",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.event-target\\ninputs=['input']\\noutputs=['listener']\\nprerequisites=constructionProfile.constraints\\nimplementation_template={target}.addEventListener({event}, {handler});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.event-target\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.websocket",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "WebSocket",
    implementation: "new WebSocket({url});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['WebSocket'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.websocket",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.websocket\\ninputs=['input']\\noutputs=['WebSocket']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new WebSocket({url});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.websocket\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.web-worker",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "Web Worker",
    implementation: "new Worker({url});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['Worker'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.web-worker",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.web-worker\\ninputs=['input']\\noutputs=['Worker']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new Worker({url});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.web-worker\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.broadcast-channel",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "BroadcastChannel",
    implementation: "new BroadcastChannel({name});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['channel'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.broadcast-channel",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.broadcast-channel\\ninputs=['input']\\noutputs=['channel']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new BroadcastChannel({name});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.broadcast-channel\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.indexeddb",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "IndexedDB",
    implementation: "indexedDB.open({name}, {version});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['database request'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.indexeddb",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.indexeddb\\ninputs=['input']\\noutputs=['database request']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=indexedDB.open({name}, {version});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.indexeddb\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.storage",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "Web Storage",
    implementation: "localStorage.setItem({key}, {value});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['void'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.storage",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.storage\\ninputs=['input']\\noutputs=['void']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=localStorage.setItem({key}, {value});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.storage\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.clipboard",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "Clipboard",
    implementation: "await navigator.clipboard.writeText({value});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['promise'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.clipboard",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.clipboard\\ninputs=['input']\\noutputs=['promise']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=await navigator.clipboard.writeText({value});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.clipboard\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.intersection-observer",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "IntersectionObserver",
    implementation: "new IntersectionObserver({callback}, {options});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['observer'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.intersection-observer",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.intersection-observer\\ninputs=['input']\\noutputs=['observer']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new IntersectionObserver({callback}, {options});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.intersection-observer\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },
  {
    knowledgeId: "code.web-api.resize-observer",
    componentType: 'CODE_CONSTRUCTION',
    purpose: "ResizeObserver",
    implementation: "new ResizeObserver({callback});",
    targetPath: 'generated.ts',
    inputs: ['input'],
    outputs: ['observer'],
    prerequisites: ['Use the canonical API or architecture represented by this knowledge item.'],
    dependencies: [],
    supportedEnvironments: ['MIKI_RUNTIME', 'ANDROID'],
    entryPoint: "CodeConstruction/code.web-api.resize-observer",
    securityClass: 'READ_ONLY',
    exports: [],
    imports: [],
    publicInterfaces: [],
    tests: "CONTRACT_TEST_SPEC:\\nknowledge=code.web-api.resize-observer\\ninputs=['input']\\noutputs=['observer']\\nprerequisites=constructionProfile.constraints\\nimplementation_template=new ResizeObserver({callback});",
    validation: "VALIDATION_SPEC:\\nknowledge=code.web-api.resize-observer\\nrequiredValidation=['Use the canonical API or architecture represented by this knowledge item.']\\ndependencies=[]\\nsupportedEnvironments=['MIKI_RUNTIME','ANDROID']\\ninitialStatus=CANDIDATE\\nverificationRequired=ANALYZED,CLOUD_TESTED,DEVICE_TESTED,VERIFIED",
  },

  {
    knowledgeId: 'code.browser-web-api.abort-controller',
    componentType: 'CODE_CONSTRUCTION',
    purpose: '非同期処理をキャンセル可能にする',
    implementation: 'const {name} = new AbortController();',
    targetPath: 'generated.ts',
    inputs: ['identifier'],
    outputs: ['statement'],
    prerequisites: ['browser AbortController'],
    dependencies: ['AbortController'],
    supportedEnvironments: ['BROWSER', 'ANDROID'],
    entryPoint: 'AbortController',
    securityClass: 'STANDARD',
    exports: [],
    imports: [],
    publicInterfaces: ['AbortController'],
    tests: 'CONTRACT_TEST:code.browser-web-api.abort-controller',
    validation: 'VALIDATE_CODE_CONSTRUCTION:code.browser-web-api.abort-controller',
  },
  {
    knowledgeId: 'code.browser-web-api.form-data',
    componentType: 'CODE_CONSTRUCTION',
    purpose: 'フォームデータを構成する',
    implementation: 'const {name} = new FormData();',
    targetPath: 'generated.ts',
    inputs: ['identifier'],
    outputs: ['statement'],
    prerequisites: ['browser FormData'],
    dependencies: ['FormData'],
    supportedEnvironments: ['BROWSER', 'ANDROID'],
    entryPoint: 'FormData',
    securityClass: 'STANDARD',
    exports: [],
    imports: [],
    publicInterfaces: ['FormData'],
    tests: 'CONTRACT_TEST:code.browser-web-api.form-data',
    validation: 'VALIDATE_CODE_CONSTRUCTION:code.browser-web-api.form-data',
  },
  {
    knowledgeId: 'code.browser-web-api.url-search-params',
    componentType: 'CODE_CONSTRUCTION',
    purpose: 'URLクエリパラメータを構成する',
    implementation: 'const {name} = new URLSearchParams({init});',
    targetPath: 'generated.ts',
    inputs: ['identifier', 'expression'],
    outputs: ['statement'],
    prerequisites: ['URLSearchParams'],
    dependencies: ['URLSearchParams'],
    supportedEnvironments: ['BROWSER', 'ANDROID', 'NODE'],
    entryPoint: 'URLSearchParams',
    securityClass: 'STANDARD',
    exports: [],
    imports: [],
    publicInterfaces: ['URLSearchParams'],
    tests: 'CONTRACT_TEST:code.browser-web-api.url-search-params',
    validation: 'VALIDATE_CODE_CONSTRUCTION:code.browser-web-api.url-search-params',
  },
  {
    "knowledgeId": "code.browser-web-api.fetch",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "Fetch APIでHTTPリクエストを送る",
    "implementation": "fetch({url})",
    "targetPath": "generated.ts",
    "inputs": [
      "string-expression"
    ],
    "outputs": [
      "promise-expression"
    ],
    "prerequisites": [],
    "dependencies": [],
    "supportedEnvironments": [
      "ANDROID",
      "MIKI_RUNTIME"
    ],
    "entryPoint": "CodeConstruction/code.browser-web-api.fetch",
    "securityClass": "READ_ONLY",
    "exports": [],
    "imports": [],
    "publicInterfaces": [],
    "tests": "CONTRACT_TEST:code.browser-web-api.fetch",
    "validation": "VALIDATE_CODE_CONSTRUCTION:code.browser-web-api.fetch"
  },
  {
    "knowledgeId": "code.browser-web-api.blob",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "Blob値を構成する",
    "implementation": "new Blob([{parts}], {type})",
    "targetPath": "generated.ts",
    "inputs": [
      "expression",
      "string-expression"
    ],
    "outputs": [
      "expression"
    ],
    "prerequisites": [],
    "dependencies": [],
    "supportedEnvironments": [
      "ANDROID",
      "MIKI_RUNTIME"
    ],
    "entryPoint": "CodeConstruction/code.browser-web-api.blob",
    "securityClass": "READ_ONLY",
    "exports": [],
    "imports": [],
    "publicInterfaces": [],
    "tests": "CONTRACT_TEST:code.browser-web-api.blob",
    "validation": "VALIDATE_CODE_CONSTRUCTION:code.browser-web-api.blob"
  },
  {
    "knowledgeId": "code.browser-web-api.local-storage",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "キー値ストレージを利用する",
    "implementation": "localStorage.setItem({key}, {value})",
    "targetPath": "generated.ts",
    "inputs": [
      "string-expression",
      "expression"
    ],
    "outputs": [
      "expression"
    ],
    "prerequisites": [],
    "dependencies": [],
    "supportedEnvironments": [
      "ANDROID",
      "MIKI_RUNTIME"
    ],
    "entryPoint": "CodeConstruction/code.browser-web-api.local-storage",
    "securityClass": "READ_ONLY",
    "exports": [],
    "imports": [],
    "publicInterfaces": [],
    "tests": "CONTRACT_TEST:code.browser-web-api.local-storage",
    "validation": "VALIDATE_CODE_CONSTRUCTION:code.browser-web-api.local-storage"
  },
  {
    "knowledgeId": "code.browser-web-api.url",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "URLを解析・構成する",
    "implementation": "new URL({value})",
    "targetPath": "generated.ts",
    "inputs": [
      "string-expression"
    ],
    "outputs": [
      "expression"
    ],
    "prerequisites": [],
    "dependencies": [],
    "supportedEnvironments": [
      "ANDROID",
      "MIKI_RUNTIME"
    ],
    "entryPoint": "CodeConstruction/code.browser-web-api.url",
    "securityClass": "READ_ONLY",
    "exports": [],
    "imports": [],
    "publicInterfaces": [],
    "tests": "CONTRACT_TEST:code.browser-web-api.url",
    "validation": "VALIDATE_CODE_CONSTRUCTION:code.browser-web-api.url"
  },
  {
    "knowledgeId": "code.browser-web-api.intersection-observer",
    "componentType": "CODE_CONSTRUCTION",
    "purpose": "要素の可視領域変化を監視する",
    "implementation": "new IntersectionObserver({callback})",
    "targetPath": "generated.ts",
    "inputs": [
      "function-expression"
    ],
    "outputs": [
      "expression"
    ],
    "prerequisites": [],
    "dependencies": [],
    "supportedEnvironments": [
      "ANDROID",
      "MIKI_RUNTIME"
    ],
    "entryPoint": "CodeConstruction/code.browser-web-api.intersection-observer",
    "securityClass": "READ_ONLY",
    "exports": [],
    "imports": [],
    "publicInterfaces": [],
    "tests": "CONTRACT_TEST:code.browser-web-api.intersection-observer",
    "validation": "VALIDATE_CODE_CONSTRUCTION:code.browser-web-api.intersection-observer"
  }

];
